function  plotPHTMesh_nodesGlobal1( PHUTelem,GIFTmesh,p)
%Face encoding: 1 - front, 2 - right, 3 - back, 4 - left, 5 - bottom, 6 - top

colorArray = {'blue', 'red', 'green', 'cyan', 'magenta', 'black'};
numPts = p+1; % Number of plot points on each edge
space = 0.3;
uref = linspace(-1+space, 1-space, numPts);
vref = linspace(-1+space, 1-space, numPts);
wref = linspace(-1+space, 1-space, numPts); % For 3D
urefEdge = linspace(-1, 1, numPts);
vrefEdge = linspace(-1, 1, numPts);
wrefEdge = linspace(-1, 1, numPts); % For 3D

figure; hold on;
axis equal; grid on;
xlabel('X'); ylabel('Y'); zlabel('Z');
view(3); % Ensure 3D view is set

for patchIndex = 1:length(PHUTelem)
    colorIndex = rem((patchIndex-1), 6) + 1;
    for elemIndex = 1:length(PHUTelem{patchIndex})
        if isempty(PHUTelem{patchIndex}(elemIndex).children)
            % Get element vertices
            xmin = PHUTelem{patchIndex}(elemIndex).vertex(1);
            ymin = PHUTelem{patchIndex}(elemIndex).vertex(2);
            zmin = PHUTelem{patchIndex}(elemIndex).vertex(3);
            xmax = PHUTelem{patchIndex}(elemIndex).vertex(4);
            ymax = PHUTelem{patchIndex}(elemIndex).vertex(5);
            zmax = PHUTelem{patchIndex}(elemIndex).vertex(6);
            
            count = 0;
            nodes = PHUTelem{patchIndex}(elemIndex).nodes;
            
            % Plot nodes with numbering
            for kk = 1:numPts
                for jj = 1:numPts
                    for ii = 1:numPts
                        count = count + 1;
                        [coord, ~] = paramMap3D(GIFTmesh{patchIndex}, uref(ii), vref(jj), wref(kk), xmin, ymin, zmin, xmax, ymax, zmax);
                        plot3(coord(1), coord(2), coord(3), 'ko', 'MarkerFaceColor', colorArray{colorIndex});
                        text(coord(1), coord(2), coord(3), num2str(nodes(count)), 'Color', colorArray{colorIndex});
                    end
                end
            end
            
            % Store 3D face coordinates
            coord_faces = zeros(numPts, numPts, 3, 6);
            for ii = 1:numPts
                for jj = 1:numPts
                    % Face mapping
                    coord_faces(ii,jj,:,1) = paramMap3D(GIFTmesh{patchIndex}, urefEdge(ii), vrefEdge(jj), wrefEdge(1), xmin, ymin, zmin, xmax, ymax, zmax); % Front (zmin)
                    coord_faces(ii,jj,:,2) = paramMap3D(GIFTmesh{patchIndex}, urefEdge(ii), vrefEdge(jj), wrefEdge(end), xmin, ymin, zmin, xmax, ymax, zmax); % Back (zmax)
                    coord_faces(ii,jj,:,3) = paramMap3D(GIFTmesh{patchIndex}, urefEdge(ii), vrefEdge(1), wrefEdge(jj), xmin, ymin, zmin, xmax, ymax, zmax); % Bottom (ymin)
                    coord_faces(ii,jj,:,4) = paramMap3D(GIFTmesh{patchIndex}, urefEdge(ii), vrefEdge(end), wrefEdge(jj), xmin, ymin, zmin, xmax, ymax, zmax); % Top (ymax)
                    coord_faces(ii,jj,:,5) = paramMap3D(GIFTmesh{patchIndex}, urefEdge(1), vrefEdge(ii), wrefEdge(jj), xmin, ymin, zmin, xmax, ymax, zmax); % Left (xmin)
                    coord_faces(ii,jj,:,6) = paramMap3D(GIFTmesh{patchIndex}, urefEdge(end), vrefEdge(ii), wrefEdge(jj), xmin, ymin, zmin, xmax, ymax, zmax); % Right (xmax)
                end
            end
            
            % Draw 3D edges
            for ii = 1:numPts
                for faceIdx = 1:6
                    plot3(squeeze(coord_faces(ii,:,1,faceIdx)), squeeze(coord_faces(ii,:,2,faceIdx)), squeeze(coord_faces(ii,:,3,faceIdx)), ...
                          'Color', colorArray{colorIndex}, 'LineWidth', 2);
                end
            end
            drawnow;
        end
    end
end