function msh_to_vtu_3dVM_20points1(pts, u, ~, ~, npts, filename)
% Export a 3D unstructured mesh to VTK format (displacement only, scalar field)

rdim = size(pts, 1);  % 3
nel = size(pts, 3);   % Number of elements

% Ensure pts is 3D (3 x 20 x nel)
if rdim == 2
    pts(3,:,:) = 0;
end

npoints = 20 * nel;
ncells  = nel;

% File setup
if ~endsWith(filename, '.vtu')
    filename = [filename, '.vtu'];
end
fid = fopen(filename, 'w');
if fid < 0
    error(['Cannot open file: ', filename]);
end

% ---------------- HEADER ----------------
fprintf(fid, '<?xml version="1.0"?>\n');
fprintf(fid, '<VTKFile type="UnstructuredGrid" version="0.1">\n');
fprintf(fid, '<UnstructuredGrid>\n');
fprintf(fid, '<Piece NumberOfPoints="%d" NumberOfCells="%d">\n', npoints, ncells);

% ---------------- POINT DATA: scalar u ----------------
fprintf(fid, '<PointData Scalars="u">\n');
fprintf(fid, '<DataArray type="Float64" Name="u" format="ascii" NumberOfComponents="1">\n');
fprintf(fid, '%g\n', u(:));
fprintf(fid, '</DataArray>\n');
fprintf(fid, '</PointData>\n');

% ---------------- POINTS ----------------
fprintf(fid, '<Points>\n');
fprintf(fid, '<DataArray type="Float64" NumberOfComponents="3" format="ascii">\n');
for e = 1:nel
    for i = 1:20
        fprintf(fid, '%g %g %g\n', pts(1,i,e), pts(2,i,e), pts(3,i,e));
    end
end
fprintf(fid, '</DataArray>\n');
fprintf(fid, '</Points>\n');

% ---------------- CELLS ----------------
fprintf(fid, '<Cells>\n');

% --- Connectivity ---
fprintf(fid, '<DataArray type="Int32" Name="connectivity" format="ascii">\n');
for e = 0:nel-1
    conn = 0:19; % Local 20-node connectivity
    fprintf(fid, '%d ', conn + 20*e);
    fprintf(fid, '\n');
end
fprintf(fid, '</DataArray>\n');

% --- Offsets ---
fprintf(fid, '<DataArray type="Int32" Name="offsets" format="ascii">\n');
fprintf(fid, '%d\n', (20:20:20*ncells));
fprintf(fid, '</DataArray>\n');

% --- Types ---
fprintf(fid, '<DataArray type="Int32" Name="types" format="ascii">\n');
fprintf(fid, '%d\n', 25 * ones(ncells,1));  % 25 = Quadratic Hexahedron
fprintf(fid, '</DataArray>\n');

fprintf(fid, '</Cells>\n');

% ---------------- FOOTER ----------------
fprintf(fid, '</Piece>\n');
fprintf(fid, '</UnstructuredGrid>\n');
fprintf(fid, '</VTKFile>\n');

fclose(fid);
disp(['✅ VTU file written: ', filename])
end
