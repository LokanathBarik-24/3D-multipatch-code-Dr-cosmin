function [ nodes, elements ] = sortFaceNodesElem( PHTelem, face, p, q, r )
% Outputs the nodes and elements along the given face, sorted in the order
% they appear in the parameter space
% Face encoding: 1 - front, 2 - right, 3 - back, 4 - left, 5 - down, 6 - up

numEdges = length(face);
elements = cell(1, numEdges);
nodes = cell(1, numEdges);

%initiialize array to store the corners of the edge elements and the edge element indices,
%for sorting purposes
verticesDown = [];
verticesRight = [];
verticesUp = [];
verticesLeft = [];
verticesFront = [];
verticesBack = [];

elementsDown = [];
elementsRight = [];
elementsUp = [];
elementsLeft = [];
elementsFront = [];
elementsBack = [];

% Define face node indices
front_nodes = reshape((1:p+1)' + (0:r)*(p+1)*(q+1), 1, []);
right_nodes = (p+1):(p+1):(p+1)*(q+1)*(r+1);
back_nodes = reshape((p*(q+1)+1:(p+1)*(q+1))' + (0:r)*(p+1)*(q+1), 1, []);
left_nodes = 1:(p+1):(p+1)*(q+1)*(r+1);
down_nodes = 1:(p+1)*(q+1);
up_nodes = (p+1)*(q+1)*(r)+1:(p+1)*(q+1)*(r+1);


for elemIndex = 1:length(PHTelem)
    if isempty(PHTelem(elemIndex).children)
        for faceIndex = 1:numEdges
            
            % Front face (y = 0) ymax
            if (face(faceIndex) == 1) && isempty(PHTelem(elemIndex).neighbor_front)
                elementsFront = [elementsFront, elemIndex];
                verticesFront = [verticesFront, PHTelem(elemIndex).vertex(3)];
            end
            
            % Right face (x = 1) xmin
            if (face(faceIndex) == 2) && isempty(PHTelem(elemIndex).neighbor_right)
                elementsRight = [elementsRight, elemIndex];
                verticesRight = [verticesRight, PHTelem(elemIndex).vertex(2)];
            end
            
            % Back face (y = 1) ymin
            if (face(faceIndex) == 3) && isempty(PHTelem(elemIndex).neighbor_back)
                elementsBack = [elementsBack, elemIndex];
                verticesBack = [verticesBack, PHTelem(elemIndex).vertex(3)];
            end
            
            % Left face (x = 0) xmin
            if (face(faceIndex) == 4) && isempty(PHTelem(elemIndex).neighbor_left)
                elementsLeft = [elementsLeft, elemIndex];
                verticesLeft = [verticesLeft, PHTelem(elemIndex).vertex(2)];
            end
            
            % Down face (z = 0) zmin
            if (face(faceIndex) == 5) && isempty(PHTelem(elemIndex).neighbor_down)
                elementsDown = [elementsDown, elemIndex];
                verticesDown = [verticesDown, PHTelem(elemIndex).vertex(1)];
            end
            
            % Up face (z = 1) zmax
            if (face(faceIndex) == 6) && isempty(PHTelem(elemIndex).neighbor_up)
                elementsUp = [elementsUp, elemIndex];
                verticesUp = [verticesUp, PHTelem(elemIndex).vertex(1)];
            end
        end
    end
end


%sort the elements according to vertex location
for edgeIndex=1:numEdges
    if (face(edgeIndex) == 1)
        [verticesFront, indexSort] = sort(verticesFront);
        %rearrange the elements according to the sorting oder
        elementsFront = elementsFront(indexSort);
        elements{edgeIndex} = elementsFront;
        for elemIndex = 1:length(verticesFront)
            nodes{edgeIndex} = [nodes{edgeIndex}, PHTelem(elementsFront(elemIndex)).nodesGlobal(front_nodes)];
        end
    end
    
    if (face(edgeIndex) == 2)
        [verticesRight, indexSort] = sort(verticesRight);
        %rearrange the elements according to the sorting oder
        elementsRight=elementsRight(indexSort);
        elements{edgeIndex} = elementsRight;
        for elemIndex = 1:length(verticesRight)              
            nodes{edgeIndex} = [nodes{edgeIndex}, PHTelem(elementsRight(elemIndex)).nodesGlobal(right_nodes)];
        end
    end

    if (face(edgeIndex) == 3)
        [verticesBack, indexSort] = sort(verticesBack);
        %rearrange the elements according to the sorting oder
        elementsBack = elementsBack(indexSort);
        elements{edgeIndex} = elementsBack;
        for elemIndex = 1:length(verticesBack)
            nodes{edgeIndex} = [nodes{edgeIndex}, PHTelem(elementsBack(elemIndex)).nodesGlobal(back_nodes)];
        end
    end

    if (face(edgeIndex) == 4)
        [verticesLeft, indexSort] = sort(verticesLeft);
        %rearrange the elements according to the sorting oder
        elementsLeft = elementsLeft(indexSort);
        elements{edgeIndex} = elementsLeft;
        for elemIndex = 1:length(verticesLeft)
            nodes{edgeIndex} = [nodes{edgeIndex}, PHTelem(elementsLeft(elemIndex)).nodesGlobal(left_nodes)];
        end
    end
    
    if (face(edgeIndex) == 5)
        [verticesDown, indexSort] = sort(verticesDown);
        %rearrange the elements according to the sorting oder
        elementsDown=elementsDown(indexSort);
        elements{edgeIndex} = elementsDown;
        for elemIndex = 1:length(verticesDown)              
            nodes{edgeIndex} = [nodes{edgeIndex}, PHTelem(elementsDown(elemIndex)).nodesGlobal(down_nodes)];
        end
    end
    
    if (face(edgeIndex) == 6)
        [verticesUp, indexSort] = sort(verticesUp);        
        %rearrange the elements according to the sorting oder
        elementsUp = elementsUp(indexSort);
        elements{edgeIndex} = elementsUp;
        for elemIndex = 1:length(verticesUp)
            nodes{edgeIndex} = [nodes{edgeIndex}, PHTelem(elementsUp(elemIndex)).nodesGlobal(up_nodes)];
        end
    end
    
    %remove duplicate nodes
    nodes{edgeIndex} = unique_stab(nodes{edgeIndex});
    %nodes{edgeIndex} = unique(nodes{edgeIndex},'stable');
end
