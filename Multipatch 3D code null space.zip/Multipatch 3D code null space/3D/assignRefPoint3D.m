function [refPoint] = assignRefPoint3D( iu,iv, uref,vref,wref,edgeA,edgeB )
% assign reference point on a 3D face
% Face encoding:
%   1 - front  (v = -1)  → varies in (u, w)
%   2 - right  (u = +1)  → varies in (v, w)
%   3 - back   (v = +1)  → varies in (u, w)
%   4 - left   (u = -1)  → varies in (v, w)
%   5 - bottom (w = -1)  → varies in (u, v)
%   6 - top    (w = +1)  → varies in (u, v)
% Face encoding: 1 - front, 2 - right, 3 - back, 4 - left, 5 - down, 6 - up

switch edgeA
    case 1
        vrefA=-1;
        urefA=uref(iu);
        wrefA=wref(iv);
    case 2
        vrefA=vref(iu);
        wrefA=wref(iv);
        urefA=1;
    case 3
        vrefA=1;
        urefA=uref(iu);
        wrefA=wref(iv);
    case 4
        vrefA=vref(iu);
        wrefA=wref(iv);
        urefA=-1;
    case 5
        urefA=uref(iu);
        vrefA=vref(iv);
        wrefA=-1;
    case 6
        urefA=uref(iu);
        vrefA=vref(iv);
        wrefA=1;
end

switch edgeB
    case 1
        vrefB=-1;
        urefB=uref(iu);
        wrefB=wref(iv);
    case 2
        vrefB=vref(iu);
        wrefB=wref(iv);
        urefB=1;
    case 3
        vrefB=1;
        urefB=uref(iu);
        wrefB=wref(iv);
    case 4
        vrefB=vref(iu);
        wrefB=wref(iv);
        urefB=-1;
    case 5
        urefB=uref(iu);
        vrefB=vref(iv);
        wrefB=-1;
    case 6
        urefB=uref(iu);
        vrefB=vref(iv);
        wrefB=1;
end

refPoint=struct;
refPoint.urefA=urefA;
refPoint.vrefA=vrefA;
refPoint.wrefA=wrefA;
refPoint.urefB=urefB;
refPoint.vrefB=vrefB;
refPoint.wrefB=wrefB;

end

