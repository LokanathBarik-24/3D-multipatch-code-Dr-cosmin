function [N, dN, d2N]=nurbshape3d_gift(u_hat, v_hat, w_hat, wgts, Ce, p, q, r)

%calculate the shape function and first derivatives
%INPUT:
%       u_hat - evaluation point in u-direction reference coordinates (from -1 to 1)
%       v_hat - evaluation point in v-direction reference coordinates (from -1 to 1)
%       w_hat - evaluation point in w-direction reference coordinates (from
%       -1 to 1)
%
%       Ce - local Bezier extraction operator
%       p,q,r - polynomial degrees
%OUTPUT: N - value of the (p+1)*(q+1)*(r+1) shape functions at the evaluation point
%        dN - derivatives of the (p+1)*(q+1)*(r+1) shape functions in physical
%        coordinates (with respect to x)
% ------------------------------------------------------------------

%     evaluate 1d shape functions and derivatives
[B_u, dB_u, d2B_u] = bernstein_basis(u_hat,p);
[B_v, dB_v, d2B_v] = bernstein_basis(v_hat,q);
[B_w, dB_w, d2B_w] = bernstein_basis(w_hat,r);

num_basis = (p+1) * (q+1) * (r+1);
B = zeros(1, num_basis);
dBxi = zeros(1, num_basis);
dBeta = zeros(1, num_basis);
dBzeta = zeros(1, num_basis);
d2Bxi2 = zeros(1, num_basis);
d2Beta2 = zeros(1, num_basis);
d2Bzeta2 = zeros(1, num_basis);
d2BxiBeta = zeros(1, num_basis);
d2BetaZeta = zeros(1, num_basis);
d2BzetaXi = zeros(1, num_basis);

basisCounter = 0;
for k = 1:r+1
    for j = 1:q+1
        for i = 1:p+1
            basisCounter = basisCounter + 1;
            B(basisCounter) = B_u(i) * B_v(j) * B_w(k);
            dBxi(basisCounter) = dB_u(i) * B_v(j) * B_w(k);
            dBeta(basisCounter) = B_u(i) * dB_v(j) * B_w(k);
            dBzeta(basisCounter) = B_u(i) * B_v(j) * dB_w(k);
            d2Bxi2(basisCounter) = d2B_u(i) * B_v(j) * B_w(k);
            d2Beta2(basisCounter) = B_u(i) * d2B_v(j) * B_w(k);
            d2Bzeta2(basisCounter) = B_u(i) * B_v(j) * d2B_w(k);
            d2BxiBeta(basisCounter) = dB_u(i) * dB_v(j) * B_w(k);
            d2BetaZeta(basisCounter) = B_u(i) * dB_v(j) * dB_w(k);
            d2BzetaXi(basisCounter) = dB_u(i) * B_v(j) * dB_w(k);
        end
    end
end

% Apply Bezier extraction operator
B = B * Ce';
dBxi = dBxi * Ce';
dBeta = dBeta * Ce';
dBzeta = dBzeta * Ce';
d2Bxi2 = d2Bxi2 * Ce';
d2Beta2 = d2Beta2 * Ce';
d2Bzeta2 = d2Bzeta2 * Ce';
d2BxiBeta = d2BxiBeta * Ce';
d2BetaZeta = d2BetaZeta * Ce';
d2BzetaXi = d2BzetaXi * Ce';


% Compute weighted shape functions
N = B .* wgts';
dN = [dBxi .* wgts'; dBeta .* wgts'; dBzeta .* wgts'];
d2N = [d2Bxi2 .* wgts'; 
       d2BxiBeta .* wgts'; 
       d2BzetaXi .* wgts'; 
       d2Beta2 .* wgts'; 
       d2BetaZeta .* wgts'; 
       d2Bzeta2 .* wgts'];

% Compute weighted sums
w_sum = sum(N);
dw_xi = sum(dN(1,:));
dw_eta = sum(dN(2,:));
dw_zeta = sum(dN(3,:));

d2w_xi2 = sum(d2N(1,:));
d2w_xi_eta = sum(d2N(2,:));
d2w_eta2 = sum(d2N(3,:));
d2w_zeta_xi = sum(d2N(4,:));
d2w_eta_zeta = sum(d2N(5,:));
d2w_zeta2 = sum(d2N(6,:));

% Compute final NURBS basis functions and derivatives
N = N / w_sum;

dN(1,:) = dN(1,:) / w_sum - N * dw_xi / w_sum^2;
dN(2,:) = dN(2,:) / w_sum - N * dw_eta / w_sum^2;
dN(3,:) = dN(3,:) / w_sum - N * dw_zeta / w_sum^2;

d2N(1,:) = d2N(1,:)/w_sum - (2*dN(1,:)*dw_xi + N*d2w_xi2)/w_sum^2 + 2*N*dw_xi^2/w_sum^3; %dxidxi derivative
d2N(2,:) = d2N(2,:)/w_sum - (dN(1,:)*dw_eta + dN(2,:)*dw_xi + N*d2w_xi_eta)/w_sum^2 + 2*N*dw_xi*dw_eta/w_sum^3; %dxideta derivative
d2N(3,:) = d2N(3,:)/w_sum - (2*dN(2,:)*dw_eta + N*d2w_eta2)/w_sum^2 + 2*N*dw_eta^2/w_sum^3; %detadeta derivative
d2N(4,:) = d2N(4,:)/w_sum - (dN(3,:)*dw_xi + dN(1,:)*dw_zeta + N*d2w_zeta_xi)/w_sum^2 + 2*N*dw_zeta*dw_xi/w_sum^3; %dxidzeta derivative
d2N(5,:) = d2N(5,:)/w_sum - (dN(2,:)*dw_zeta + dN(3,:)*dw_eta + N*d2w_eta_zeta)/w_sum^2 + 2*N*dw_eta*dw_zeta/w_sum^3; %detadzeta derivative
d2N(6,:) = d2N(6,:)/w_sum - (2*dN(3,:)*dw_zeta + N*d2w_zeta2)/w_sum^2 + 2*N*dw_zeta^2/w_sum^3; %dzetadzeta derivative

