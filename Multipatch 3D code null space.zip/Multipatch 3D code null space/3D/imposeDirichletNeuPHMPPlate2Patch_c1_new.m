function [ stiff, rhs, bcdof, bcval ] = imposeDirichletNeuPHMPPlate2Patch_c1_new(stiff, rhs, PHTelem, p, q, numPatches,type2Basis)
%impose Dirichlet boundary conditions for the simply supported plate problem
%fixed (homogeneous) boundary conditions on the left, right, top, bottom sides
%for one patch only
% 2 nodes at each boundary
% two patches

%detect which nodes have support on the left and right boundary
bcdof_left = [];
bcdof_right = [];
bcdof_up = [];
bcdof_down = [];

%define side node indices
down_nodes = 1:p+1;
right_nodes = (p+1):(p+1):(p+1)*(q+1);
up_nodes = 1+(p+1)*q:(p+1)*(q+1);
left_nodes = 1:(p+1):(1+(p+1)*q);

down_nodes2 = p+2:p+(p+2);
right_nodes2 = (p):(p+1):(p+1)*(q+1)-1;
up_nodes2 = (p+1)*q-p:(p+1)*(q+1)-p-1;
left_nodes2 = 2:(p+1):(1+(p+1)*q)+1;

%set the boundary degree of freedom and elements from the 1st patch
for indexPatch = 1:numPatches
    for i=1:length(PHTelem{indexPatch})
        if isempty(PHTelem{indexPatch}(i).children)
            
            numBasis=length(PHTelem{indexPatch}(i).nodesGlobal);
            
            if isempty(PHTelem{indexPatch}(i).neighbor_right) && (indexPatch==2)
                
                nodes=[right_nodes,right_nodes2];
                % nodes=right_nodes;
                
                for ii=1:length(nodes)
                    if nodes(ii)<=numBasis
                        bcdof_right = [bcdof_right,PHTelem{indexPatch}(i).nodesGlobal(nodes(ii))];
                    end
                end
                
                % bcdof_right = [bcdof_right, PHTelem{indexPatch}(i).nodesGlobal(right_nodes),PHTelem{indexPatch}(i).nodesGlobal(right_nodes2)];
            end
            
            if isempty(PHTelem{indexPatch}(i).neighbor_down)
                
                nodes=[down_nodes,down_nodes2];
                % nodes=down_nodes;
                
                for ii=1:length(nodes)
                    if nodes(ii)<=numBasis
                        bcdof_down = [bcdof_down,PHTelem{indexPatch}(i).nodesGlobal(nodes(ii))];
                    end
                end
                
                % bcdof_down = [bcdof_down, PHTelem{indexPatch}(i).nodesGlobal(down_nodes), PHTelem{indexPatch}(i).nodesGlobal(down_nodes2)];
            end
            
            if isempty(PHTelem{indexPatch}(i).neighbor_up)
                
                nodes=[up_nodes,up_nodes2];
                % nodes=up_nodes;
                
                for ii=1:length(nodes)
                    if nodes(ii)<=numBasis
                        bcdof_up = [bcdof_up,PHTelem{indexPatch}(i).nodesGlobal(nodes(ii))];
                    end
                end
                
                %bcdof_up = [bcdof_up, PHTelem{indexPatch}(i).nodesGlobal(up_nodes),PHTelem{indexPatch}(i).nodesGlobal(up_nodes2)];
            end
            
            if isempty(PHTelem{indexPatch}(i).neighbor_left) && (indexPatch==1)
                
                nodes=[left_nodes,left_nodes2];
                % nodes=left_nodes;
                
                for ii=1:length(nodes)
                    if nodes(ii)<=numBasis
                        bcdof_left = [bcdof_left,PHTelem{indexPatch}(i).nodesGlobal(nodes(ii))];
                    end
                end
                
                %bcdof_left = [bcdof_left, PHTelem{indexPatch}(i).nodesGlobal(left_nodes),PHTelem{indexPatch}(i).nodesGlobal(left_nodes2)];
            end
        end
    end
end


%remove duplicated entries
bcdof1  =  unique([bcdof_down, bcdof_up]);
bcdof2  =  unique([bcdof_left, bcdof_right]);
bcdof = unique([bcdof_down, bcdof_up, bcdof_left, bcdof_right]);

%make sure the type2basis are not included in the Dirichlet boundary conditions
bcdof = setdiff(bcdof,type2Basis);
bcdof1 = setdiff(bcdof1,type2Basis);
bcdof2 = setdiff(bcdof2,type2Basis);



%update the stiffness matrix and rhs with Dirichlet boundary values
% bcdof=[3*bcdof-2,3*bcdof-1,3*bcdof];
bcdof=[4*bcdof-3,4*bcdof-2,4*bcdof-1,4*bcdof]; %CCCC
% bcdof=[4*bcdof1-3,4*bcdof2-2,4*bcdof-1,4*bcdof]; %SSSS
% bcdof=[4*bcdof2-2,4*bcdof-1,4*bcdof]; %SFSF
% bcdof=unique([4*bcdof2-2,4*bcdof2-1,4*bcdof2,4*bcdof1-3,4*bcdof1-2,4*bcdof1-1,4*bcdof1]); %SCSC
bcval = zeros(size(bcdof));
%bcdof
%bcval
[stiff,rhs]=feaplyc2sym(stiff, rhs, bcdof, bcval);
