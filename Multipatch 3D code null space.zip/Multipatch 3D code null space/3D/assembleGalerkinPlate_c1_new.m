function [ stiff, rhs, mass ] = assembleGalerkinPlate_c1_new( PHTelem, GIFTmesh, sizeBasis, p, q, Dt,Dc,Db,Dst,Dsc,Dsb,mt,mc,mb, q0)
%assembles the stiffness matrix and rhs (Galerkin method) for the plate
%problem
%uses GIFT mapping
%supports multipatches
%use modifiedC

%Gauss points
ngauss_x = p+2;
ngauss_y = q+2;
[gauss_weight_x, gauss_coord_x] = quadrature( ngauss_x, 'GAUSS', 1 );
[gauss_weight_y, gauss_coord_y] = quadrature( ngauss_y, 'GAUSS', 1 );

%take the transpose so that they are in the format expected by
%bernstein_basis
gauss_coord_x = gauss_coord_x';
gauss_coord_y = gauss_coord_y';

%1D bernstein polynomials evaluated at the Gauss points on the master element
[B_u, dB_u,ddB_u] = bernstein_basis(gauss_coord_x,p);
[B_v, dB_v,ddB_v] = bernstein_basis(gauss_coord_y,q);

Buv = zeros(ngauss_x, ngauss_y, (p+1)*(q+1));
dBdu = zeros(ngauss_x, ngauss_y, (p+1)*(q+1));
dBdv = zeros(ngauss_x, ngauss_y, (p+1)*(q+1));
d2Bdu = zeros(ngauss_x, ngauss_y, (p+1)*(q+1));
d2Bdv = zeros(ngauss_x, ngauss_y, (p+1)*(q+1));
d2Bdudv = zeros(ngauss_x, ngauss_y, (p+1)*(q+1));
%the derivatives of the 2D Bernstein polynomials at Gauss points on the
%master element
basisCounter = 0;
for j=1:q+1
    for i=1:p+1
        basisCounter = basisCounter + 1;
        Buv(:,:,basisCounter) = B_u(:,i)*B_v(:,j)';
        dBdu(:,:,basisCounter) = dB_u(:,i)*B_v(:,j)';
        dBdv(:,:,basisCounter) = B_u(:,i)*dB_v(:,j)';
        d2Bdu(:,:,basisCounter) = ddB_u(:,i)*B_v(:,j)';
        d2Bdv(:,:,basisCounter) = B_u(:,i)*ddB_v(:,j)';
        d2Bdudv(:,:,basisCounter) = dB_u(:,i)*dB_v(:,j)';
    end
end


%initialize LHS stiffness matrix and RHS vector
stiff = sparse(4*sizeBasis,4*sizeBasis);
mass  = sparse(4*sizeBasis,4*sizeBasis);
rhs = zeros(4*sizeBasis,1);

%assemble the stiffness matrix and RHS
domain_area = 0;
for patchIndex = 1:length(PHTelem)
    for i=1:length(PHTelem{patchIndex})
        if isempty(PHTelem{patchIndex}(i).children)
            xmin = PHTelem{patchIndex}(i).vertex(1);
            xmax = PHTelem{patchIndex}(i).vertex(3);
            ymin = PHTelem{patchIndex}(i).vertex(2);
            ymax = PHTelem{patchIndex}(i).vertex(4);
            
            %the jacobian of the transformation from [-1,1]x[-1,1] to
            %[xmin, xmax]x [ymin, ymax]
            scalefac = (xmax - xmin)*(ymax - ymin)/4;
            nument = size(PHTelem{patchIndex}(i).modifiedC,1);
            sctrx = PHTelem{patchIndex}(i).nodesGlobal(1:nument);
            nn     = length(sctrx);  
                    
            nn3    = nn*4;
            sctrB  = zeros(1,nn3);
            
            sctrB(1:4:nn3) = 4*sctrx-3; % deflection1
            sctrB(2:4:nn3) = 4*sctrx-2; % deflection2
            sctrB(3:4:nn3) = 4*sctrx-1; % deflection3
            sctrB(4:4:nn3) = 4*sctrx; % rotation 1
        
            

            %dscrtx = reshape([2*scrtx-1; 2*scrtx],1,2*nument);
            
            localstiff = zeros(4*nument, 4*nument); %local stiffness
            localmass = zeros(4*nument, 4*nument); %local mass
            localrhs = zeros(4*nument,1);
            
            %loop over the ngauss_x x ngauss_y gauss points on each element
            for jj=1:ngauss_y
                for ii=1:ngauss_x
                    %evaluate the derivatives of the mapping from parameter
                    %space to physical space
                    
                    [ coord, dxdxi, d2xdxi2, dxdxi2] = paramMapPlate( GIFTmesh{patchIndex}, gauss_coord_x(ii), gauss_coord_y(jj), xmin, ymin, xmax, ymax);
                    
                    
                    R = (PHTelem{patchIndex}(i).modifiedC)*squeeze(Buv(ii,jj,:));
                    dRdx = (PHTelem{patchIndex}(i).modifiedC)*squeeze(dBdu(ii,jj,:));
                    dRdy = (PHTelem{patchIndex}(i).modifiedC)*squeeze(dBdv(ii,jj,:));
                    d2Rdx = (PHTelem{patchIndex}(i).modifiedC)*squeeze(d2Bdu(ii,jj,:));
                    d2Rdy = (PHTelem{patchIndex}(i).modifiedC)*squeeze(d2Bdv(ii,jj,:));
                    d2Rdxdy = (PHTelem{patchIndex}(i).modifiedC)*squeeze(d2Bdudv(ii,jj,:));
                    
                    %multiply by the jacobian of the transformation from reference
                    %space to the parameter space
                    dRdx = dRdx*2/(xmax-xmin);
                    dRdy = dRdy*2/(ymax-ymin);
                    d2Rdx = d2Rdx*(2/(xmax-xmin))^2;
                    d2Rdy = d2Rdy*(2/(ymax-ymin))^2;
                    d2Rdxdy = d2Rdxdy*(2/(xmax-xmin))*(2/(ymax-ymin));
                    
                    % Solve for first derivatives in global coordinates
                    dR = dxdxi\[dRdx';dRdy'];
                    d2R =  dxdxi2\([d2Rdx';d2Rdxdy';d2Rdy']-d2xdxi2*dR);

                    J = abs(det(dxdxi));
                   
                    % bending and shear B matrices
                    %BOTTOM PLATE
                    Bb_b=zeros(9,nn3);
                    Bs_b=zeros(2,nn3);

                    Bb_b(1,1:4:nn3) = dR(1,:);
                    Bb_b(2,2:4:nn3) = dR(2,:);
                    Bb_b(3,1:4:nn3) = dR(2,:);
                    Bb_b(3,2:4:nn3) = dR(1,:);
            
                    Bb_b(4,3:4:nn3) = -d2R(1,:);
                    Bb_b(5,3:4:nn3) = -d2R(3,:);
                    Bb_b(6,3:4:nn3) = -2*d2R(2,:);
                    Bb_b(7,4:4:nn3) = d2R(1,:);
                    Bb_b(8,4:4:nn3) = d2R(3,:);
                    Bb_b(9,4:4:nn3) = 2*d2R(2,:);
            
                    Bs_b(1,4:4:nn3) = dR(2,:);
                    Bs_b(2,4:4:nn3) = dR(1,:);
            
                    Nb=zeros(9,nn3);
                    Nb(1,1:4:nn3) =  R;
                    Nb(2,3:4:nn3) =  -dR(1,:);
                    Nb(3,4:4:nn3) =  dR(1,:);
                    Nb(4,2:4:nn3) =  R;
                    Nb(5,3:4:nn3) =  -dR(2,:);
                    Nb(6,4:4:nn3) =  dR(2,:);
                    Nb(7,3:4:nn3) =  R;
                    Nb(8,4:4:nn3) =  R;
            
            
                    %TOP PLATE
                    Bb_t=zeros(9,nn3);
                    Bs_t=zeros(2,nn3);

                    Bb_t(1,1:4:nn3) = dR(1,:);
                    Bb_t(2,2:4:nn3) = dR(2,:);
                    Bb_t(3,1:4:nn3) = dR(2,:);
                    Bb_t(3,2:4:nn3) = dR(1,:);
            
                    Bb_t(4,3:4:nn3) = -d2R(1,:);
                    Bb_t(5,3:4:nn3) = -d2R(3,:);
                    Bb_t(6,3:4:nn3) = -2*d2R(2,:);
                    Bb_t(7,4:4:nn3) = d2R(1,:);
                    Bb_t(8,4:4:nn3) = d2R(3,:);
                    Bb_t(9,4:4:nn3) = 2*d2R(2,:);
            
                    Bs_t(1,4:4:nn3) = dR(2,:);
                    Bs_t(2,4:4:nn3) = dR(1,:);
            
                    Nt=zeros(9,nn3);
                    Nt(1,1:4:nn3) =  R;
                    Nt(2,3:4:nn3) =  -dR(1,:);
                    Nt(3,4:4:nn3) =  dR(1,:);
                    Nt(4,2:4:nn3) = R;
                    Nt(5,3:4:nn3) =  -dR(2,:);
                    Nt(6,4:4:nn3) =  dR(2,:);
                    Nt(7,3:4:nn3) =  R;
                    Nt(8,4:4:nn3) =  R;
            
            
                    %CORE PLATE
                    Bb_c=zeros(9,nn3);
                    Bs_c=zeros(2,nn3);

                    Bb_c(1,1:4:nn3) = dR(1,:);
                    Bb_c(2,2:4:nn3) = dR(2,:);
                    Bb_c(3,1:4:nn3) = dR(2,:);
                    Bb_c(3,2:4:nn3) = dR(1,:);
            
                    Bb_c(4,3:4:nn3) = -d2R(1,:);
                    Bb_c(5,3:4:nn3) = -d2R(3,:);
                    Bb_c(6,3:4:nn3) = -2*d2R(2,:);
                    Bb_c(7,4:4:nn3) = d2R(1,:);
                    Bb_c(8,4:4:nn3) = d2R(3,:);
                    Bb_c(9,4:4:nn3) = 2*d2R(2,:);
            
                    Bs_c(1,4:4:nn3) = dR(2,:);
                    Bs_c(2,4:4:nn3) = dR(1,:);
            
                    Nc=zeros(9,nn3);
                    Nc(1,1:4:nn3) =  R;
                    Nc(2,3:4:nn3) =  -dR(1,:);
                    Nc(3,4:4:nn3) =  dR(1,:);
                    Nc(4,2:4:nn3) = R;
                    Nc(5,3:4:nn3) =  -dR(2,:);
                    Nc(6,4:4:nn3) =  dR(2,:);
                    Nc(7,3:4:nn3) =  R;
                    Nc(8,4:4:nn3) =  R;
            
                    fn=zeros(1,4*nn);
                    fn(1,3:4:4*nn) =  R;
                    fn(1,4:4:4*nn) =  R;
                   

                    localstiff = localstiff + Bb_t' * Dt * Bb_t * scalefac * gauss_weight_x(ii).*gauss_weight_y(jj).*J+Bb_c' * Dc * Bb_c  * scalefac * gauss_weight_x(ii).*gauss_weight_y(jj).*J+ Bb_b' * Db * Bb_b  * scalefac * gauss_weight_x(ii).*gauss_weight_y(jj).*J...
                         + Bs_t' * Dst * Bs_t  * scalefac * gauss_weight_x(ii).*gauss_weight_y(jj).*J+ Bs_c' * Dsc * Bs_c  * scalefac * gauss_weight_x(ii).*gauss_weight_y(jj).*J+ Bs_b' * Dsb * Bs_b  * scalefac * gauss_weight_x(ii).*gauss_weight_y(jj).*J;%
                    localmass = localmass + Nt' * mt * Nt * scalefac * gauss_weight_x(ii).*gauss_weight_y(jj).*J+Nc' * mc * Nc * scalefac * gauss_weight_x(ii).*gauss_weight_y(jj).*J+ Nb' * mb * Nb * scalefac * gauss_weight_x(ii).*gauss_weight_y(jj).*J;%
                    localrhs = localrhs + q0*fn.'*scalefac*gauss_weight_x(ii).*gauss_weight_y(jj).*J;
                    domain_area = domain_area + scalefac * gauss_weight_x(ii).*gauss_weight_y(jj).*J;
                    
                end
            end
            stiff(sctrB, sctrB) = stiff(sctrB, sctrB) + localstiff;
            mass(sctrB, sctrB) = mass(sctrB, sctrB) + localmass;
            rhs(sctrB) = rhs(sctrB) + localrhs;
        end
    end
end


domain_area
%domain_area_error = domain_area - 10^4