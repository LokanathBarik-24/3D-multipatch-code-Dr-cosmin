restoredefaultpath
close all
clear all
addpaths

tic;

numPatches = 1;
W = 1;
L = 1;
H = 1;
GIFTmesh = init2DGeometryGIFTMP('rectangle', L, W, H, numPatches);
% GIFTmesh = init2DGeometryGIFTMP('2patch_curvedCommonBoundary', L, W, numPatches);

p=3;
q=3;
r=3;

numElemU=2;
numElemV=numElemU;
numElemW=numElemU;

PHUTelem = cell(numPatches, 1);
dimBasis = zeros(1, numPatches);
quadList = cell(numPatches, 1);

if p==2
    for indexPatch=1:numPatches
        [PHUTelem{indexPatch}, dimBasis(indexPatch), lenVec] = initPHTmesh_quadratic( p,q,r,numElemU,numElemV,numElemW);
        numElem=length(PHUTelem{indexPatch});
        quadList{indexPatch} =1:numElem;
    end
else
    for indexPatch=1:numPatches
        [PHUTelem{indexPatch}, dimBasis(indexPatch), lenVec] = initPHTmeshGen( p,q,r,numElemU,numElemV,numElemW);
        numElem=length(PHUTelem{indexPatch});
        quadList{indexPatch} =1:numElem;
    end
end

%Face encoding: 1 - front, 2 - right, 3 - back, 4 - left, 5 - bottom, 6 - top

numSteps = 3;

for stepCount = 1:numSteps

    type2Basis=[];
    allNodes=[];
    for indexPatch=1:length(PHUTelem)
       for indexElem=1:length(PHUTelem{indexPatch})
            allNodes=[allNodes,PHUTelem{indexPatch}(indexElem).nodes];
       end
    end
    
    allNodes=nonzeros(allNodes);
    allNodes=unique(allNodes);
    sizeBasis=length(allNodes);
    
        % figure
        % plotPHTMesh3DMP(PHUTelem, GIFTmesh)
        % % plotPHTMesh_nodesGlobal1( PHUTelem,GIFTmesh,p)
        % title('nodes Global')
    
    % Define the elasticity (compliance) matrix
    Cmat=zeros(6,6);
    % Cmat(1:3,1:3)=E0/(1+nu0)/(1-2*nu0)*[ 1-nu0 nu0 nu0;
    %     nu0 1-nu0 nu0;
    %     nu0 nu0 1-nu0];
    % Cmat(4:6,4:6)=E0/(1+nu0)*eye(3)/2;
    
    disp('Assembling the linear system...')
    [stiff,rhs] = assembleBiharmonic_c11_3D(PHUTelem,GIFTmesh,sizeBasis,p,q,r);
    
    disp('Imposing boundary conditions...')
    [ stiff, rhs, bcdof, bcval] = imposeDirichletBiharmonic_c11(stiff, rhs, PHUTelem, p, q ,r, numPatches,type2Basis);
    
        % figure ()
        % plotPHTMesh3DMP_bc(PHUTelem, GIFTmesh, bcdof)
        % % plotPHTMesh_nodesGlobal1( PHUTelem,GIFTmesh,p)
        % title('nodes Global')
    
    disp('Solving the linear system...')
    sol0 = stiff\rhs;
    
    % vtuFile = ['BiharmonicCubeSol',num2str(stepCount),'.vtu'];
    % plotStressDisp3DVM_20pt(PHUTelem, GIFTmesh, sol0, p, q, r, vtuFile, 0.75)
    
    size(sol0)
    [l2relerr] = calcErrorNormsBiharmonic_square3D1(PHUTelem, GIFTmesh,  p, q, r, sol0)
    % [h1relerr,h2relerr] = cal_H1_H2_square(PHUTelem, GIFTmesh,  p, q, sol0 )
    % h1_err1(stepCount)=h1relerr;
    % h2_err1(stepCount)=h2relerr;
    l2err1(stepCount) = l2relerr;
    dof1(stepCount) = sizeBasis;
    cn1(stepCount)=condest(stiff);
    
            %%%%%%%%%%%%%%%%%%%%% refinement %%%%%%%%%%%%%%%%%%%%
    if stepCount<numSteps
        numElemU=numElemU*2;
        numElemV=numElemV*2;
        numElemW=numElemW*2;
        for indexPatch=1:numPatches
            if p==2
                [PHUTelem{indexPatch}, dimBasis(indexPatch), lenVec] = initPHTmesh_quadratic( p,q,r,numElemU,numElemV,numElemW);
            else
                [PHUTelem{indexPatch}, dimBasis(indexPatch), lenVec] = initPHTmeshGen( p,q,r,numElemU,numElemV,numElemW);
            end
            numElem=length(PHUTelem{1});
            quadList{indexPatch} =1:numElem;
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
%%
tic;

numPatches = 1;
W = 1;
L = 1;
H = 1;
GIFTmesh = init2DGeometryGIFTMP('rectangle', L, W, H, numPatches);
% GIFTmesh = init2DGeometryGIFTMP('2patch_curvedCommonBoundary', L, W, numPatches);

p=2;
q=2;
r=2;

numElemU=4;
numElemV=numElemU;
numElemW=numElemU;

PHUTelem = cell(numPatches, 1);
dimBasis = zeros(1, numPatches);
quadList = cell(numPatches, 1);

if p==2
    for indexPatch=1:numPatches
        [PHUTelem{indexPatch}, dimBasis(indexPatch), lenVec] = initPHTmesh_quadratic( p,q,r,numElemU,numElemV,numElemW);
        numElem=length(PHUTelem{indexPatch});
        quadList{indexPatch} =1:numElem;
    end
else
    for indexPatch=1:numPatches
        [PHUTelem{indexPatch}, dimBasis(indexPatch), lenVec] = initPHTmeshGen( p,q,r,numElemU,numElemV,numElemW);
        numElem=length(PHUTelem{indexPatch});
        quadList{indexPatch} =1:numElem;
    end
end

%Face encoding: 1 - front, 2 - right, 3 - back, 4 - left, 5 - bottom, 6 - top

numSteps = 3;

for stepCount = 1:numSteps

    type2Basis=[];
    allNodes=[];
    for indexPatch=1:length(PHUTelem)
       for indexElem=1:length(PHUTelem{indexPatch})
            allNodes=[allNodes,PHUTelem{indexPatch}(indexElem).nodes];
       end
    end
    
    allNodes=nonzeros(allNodes);
    allNodes=unique(allNodes);
    sizeBasis=length(allNodes);
    
        % figure
        % plotPHTMesh3DMP(PHUTelem, GIFTmesh)
        % % plotPHTMesh_nodesGlobal1( PHUTelem,GIFTmesh,p)
        % title('nodes Global')
    
    % Define the elasticity (compliance) matrix
    Cmat=zeros(6,6);
    % Cmat(1:3,1:3)=E0/(1+nu0)/(1-2*nu0)*[ 1-nu0 nu0 nu0;
    %     nu0 1-nu0 nu0;
    %     nu0 nu0 1-nu0];
    % Cmat(4:6,4:6)=E0/(1+nu0)*eye(3)/2;
    
    disp('Assembling the linear system...')
    [stiff,rhs] = assembleBiharmonic_c11_3D(PHUTelem,GIFTmesh,sizeBasis,p,q,r);
    
    disp('Imposing boundary conditions...')
    [ stiff, rhs, bcdof, bcval] = imposeDirichletBiharmonic_c11(stiff, rhs, PHUTelem, p, q ,r, numPatches,type2Basis);
    
        % figure ()
        % plotPHTMesh3DMP_bc(PHUTelem, GIFTmesh, bcdof)
        % % plotPHTMesh_nodesGlobal1( PHUTelem,GIFTmesh,p)
        % title('nodes Global')
    
    disp('Solving the linear system...')
    sol0 = stiff\rhs;
    
    % vtuFile = ['BiharmonicCubeSol',num2str(stepCount),'.vtu'];
    % plotStressDisp3DVM_20pt(PHUTelem, GIFTmesh, sol0, p, q, r, vtuFile, 0.75)
    
    size(sol0)
    [l2relerr] = calcErrorNormsBiharmonic_square3D1(PHUTelem, GIFTmesh,  p, q, r, sol0)
    % [h1relerr,h2relerr] = cal_H1_H2_square(PHUTelem, GIFTmesh,  p, q, sol0 )
    % h1_err1(stepCount)=h1relerr;
    % h2_err1(stepCount)=h2relerr;
    l2err2(stepCount) = l2relerr;
    dof2(stepCount) = sizeBasis;
    cn2(stepCount)=condest(stiff);
    
            %%%%%%%%%%%%%%%%%%%%% refinement %%%%%%%%%%%%%%%%%%%%
    if stepCount<numSteps
        numElemU=numElemU*2;
        numElemV=numElemV*2;
        numElemW=numElemW*2;
        for indexPatch=1:numPatches
            if p==2
                [PHUTelem{indexPatch}, dimBasis(indexPatch), lenVec] = initPHTmesh_quadratic( p,q,r,numElemU,numElemV,numElemW);
            else
                [PHUTelem{indexPatch}, dimBasis(indexPatch), lenVec] = initPHTmeshGen( p,q,r,numElemU,numElemV,numElemW);
            end
            numElem=length(PHUTelem{1});
            quadList{indexPatch} =1:numElem;
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end

    % 
    % figure()
    % plot(log(dof1), log(l2err1), '-ro' , 'MarkerSize', 6, 'LineWidth', 2);
    % hold on 
    % plot(log(dof1), log(40)+(-4/3).*log(dof1), '--k' , 'MarkerSize', 6, 'LineWidth', 2);
    % hold on 
    % plot(log(dof2), log(l2err2), '-co' , 'MarkerSize', 6, 'LineWidth', 2);
    % hold on 
    % plot(log(dof2), log(4)+(-2/3).*log(dof2),  '--b' , 'MarkerSize', 6, 'LineWidth', 2);
    % 
    % figure()
    % plot(log(dof1), log(cn1),  'MarkerSize', 6, 'LineWidth', 2);
    % hold on
    % plot(log(dof2), log(cn2), 'MarkerSize', 6, 'LineWidth', 2);
    % 

    figure()
    loglog(dof1, l2err1, '-ro' , 'MarkerSize', 6, 'LineWidth', 2);
    hold on 
    loglog(dof1, 30 * dof1.^(-4/3), '--k' , 'MarkerSize', 6, 'LineWidth', 2);
    hold on 
    loglog(dof2, l2err2, '-co' , 'MarkerSize', 6, 'LineWidth', 2);
    hold on 
    loglog(dof2, 4 * dof2.^(-2/3),  '--b' , 'MarkerSize', 6, 'LineWidth', 2);