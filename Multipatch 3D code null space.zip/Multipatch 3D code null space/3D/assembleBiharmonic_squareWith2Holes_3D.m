function [stiff, rhs ] = assembleBiharmonic_squareWith2Holes_3D(PHTelem,GIFTmesh, sizeBasis, p, q )
%use nodesGlobal
%use modifiedC
%vectorise stiffness matrix
%Gauss points
ngauss_x = p+1;
ngauss_y = q+1;
ngauss_z = r+1;
[gauss_weight_x, gauss_coord_x] = quadrature( ngauss_x, 'GAUSS', 1 );
[gauss_weight_y, gauss_coord_y] = quadrature( ngauss_y, 'GAUSS', 1 );
[gauss_weight_z, gauss_coord_z] = quadrature( ngauss_z, 'GAUSS', 1 );

%take the transpose so that they are in the format expected by
%bernstein_basis
gauss_coord_x = gauss_coord_x';
gauss_coord_y = gauss_coord_y';
gauss_coord_z = gauss_coord_z';

%1D bernstein polynomials evaluated at the Gauss points on the master element
[B_u, dB_u, ddB_u] = bernstein_basis(gauss_coord_x,p);
[B_v, dB_v, ddB_v] = bernstein_basis(gauss_coord_y,q);
[B_w, dB_w, ddB_w] = bernstein_basis(gauss_coord_z,r);

% 3D basis function computation
Buvw = zeros(ngauss_x, ngauss_y, ngauss_z, (p+1)*(q+1)*(r+1));
dBdu = zeros(size(Buvw));
dBdv = zeros(size(Buvw));
dBdw = zeros(size(Buvw));
d2Bdu = zeros(size(Buvw));
d2Bdv = zeros(size(Buvw));
d2Bdw = zeros(size(Buvw));
d2Bdudv = zeros(size(Buvw));
d2Bdudw = zeros(size(Buvw));
d2Bdvdw = zeros(size(Buvw));

basisCounter = 0;
for k=1:r+1
    for j=1:q+1
        for i=1:p+1
            basisCounter = basisCounter + 1;
            for kk=1:ngauss_z
                for jj=1:ngauss_y
                    for ii=1:ngauss_x
                        Buvw(ii,jj,kk,basisCounter) = B_u(ii,i)*B_v(jj,j)*B_w(kk,k);
                        dBdu(ii,jj,kk,basisCounter) = dB_u(ii,i)*B_v(jj,j)*B_w(kk,k);
                        dBdv(ii,jj,kk,basisCounter) = B_u(ii,i)*dB_v(jj,j)*B_w(kk,k);
                        dBdw(ii,jj,kk,basisCounter) = B_u(ii,i)*B_v(jj,j)*dB_w(kk,k);
                        d2Bdu(ii,jj,kk,basisCounter) = ddB_u(ii,i)*B_v(jj,j)*B_w(kk,k);
                        d2Bdv(ii,jj,kk,basisCounter) = B_u(ii,i)*ddB_v(jj,j)*B_w(kk,k);
                        d2Bdw(ii,jj,kk,basisCounter) = B_u(ii,i)*B_v(jj,j)*ddB_w(kk,k);
                        d2Bdudv(ii,jj,kk,basisCounter) = dB_u(ii,i)*dB_v(jj,j)*B_w(kk,k);
                        d2Bdudw(ii,jj,kk,basisCounter) = dB_u(ii,i)*B_v(jj,j)*dB_w(kk,k);
                        d2Bdvdw(ii,jj,kk,basisCounter) = B_u(ii,i)*dB_v(jj,j)*dB_w(kk,k);
                    end
                end
            end
        end
    end
end

stiff = sparse(sizeBasis,sizeBasis);
rhs= zeros(sizeBasis,1);

for patchIndex = 1:length(PHTelem)
    for elemIndex=1:length(PHTelem{patchIndex})
        if isempty(PHTelem{patchIndex}(elemIndex).children)
            
            xmin = PHTelem{patchIndex}(elemIndex).vertex(1);
            xmax = PHTelem{patchIndex}(elemIndex).vertex(4);
            ymin = PHTelem{patchIndex}(elemIndex).vertex(2);
            ymax = PHTelem{patchIndex}(elemIndex).vertex(5);
            zmin = PHTelem{patchIndex}(elemIndex).vertex(3);
            zmax = PHTelem{patchIndex}(elemIndex).vertex(6);
            
            scalefac = (xmax - xmin)*(ymax - ymin)*(zmax - zmin)/8;
            nument = size(PHTelem{patchIndex}(elemIndex).modifiedC,1);
            scrtx = PHTelem{patchIndex}(elemIndex).nodesGlobal(1:nument);
            
            localStiff = zeros(nument, nument);
            localRhs = zeros(nument, 1);
            
            for kk=1:ngauss_z
                for jj=1:ngauss_y
                    for ii=1:ngauss_x
                    
                    R = (PHTelem{patchIndex}(elemIndex).modifiedC) * squeeze(Buvw(ii,jj,kk,:));
                    dRdx = (PHTelem{patchIndex}(elemIndex).modifiedC) * squeeze(dBdu(ii,jj,kk,:));
                    dRdy = (PHTelem{patchIndex}(elemIndex).modifiedC) * squeeze(dBdv(ii,jj,kk,:));
                    dRdz = (PHTelem{patchIndex}(elemIndex).modifiedC) * squeeze(dBdw(ii,jj,kk,:));
                    
                    % Second derivatives
                    d2Rdx = (PHTelem{patchIndex}(elemIndex).modifiedC) * squeeze(d2Bdu(ii, jj, kk, :));
                    d2Rdy = (PHTelem{patchIndex}(elemIndex).modifiedC) * squeeze(d2Bdv(ii, jj, kk, :));
                    d2Rdz = (PHTelem{patchIndex}(elemIndex).modifiedC) * squeeze(d2Bdw(ii, jj, kk, :));
                    d2Rdxdy = (PHTelem{patchIndex}(elemIndex).modifiedC) * squeeze(d2Bdudv(ii, jj, kk, :));
                    d2Rdxdz = (PHTelem{patchIndex}(elemIndex).modifiedC) * squeeze(d2Bdudw(ii, jj, kk, :));
                    d2Rdydz = (PHTelem{patchIndex}(elemIndex).modifiedC) * squeeze(d2Bdvdw(ii, jj, kk, :));
                    
                    %multiply by the jacobian of the transformation from reference
                    %space to the parameter space
                    dRdx = dRdx*2/(xmax-xmin);
                    dRdy = dRdy*2/(ymax-ymin);
                    dRdz = dRdz*2/(zmax-zmin);
                    
                    d2Rdx = d2Rdx * (2 / (xmax - xmin))^2;
                    d2Rdy = d2Rdy * (2 / (ymax - ymin))^2;
                    d2Rdz = d2Rdz * (2 / (zmax - zmin))^2;
                    d2Rdxdy = d2Rdxdy * (2 / (xmax - xmin)) * (2 / (ymax - ymin));
                    d2Rdxdz = d2Rdxdz * (2 / (xmax - xmin)) * (2 / (zmax - zmin));
                    d2Rdydz = d2Rdydz * (2 / (ymax - ymin)) * (2 / (zmax - zmin));
                    
                    
                    % [coords, dxdxi, d2xdxi2, dxdxi2] = paramMapPlate( GIFTmesh{patchIndex},gauss_coord_x(ii), gauss_coord_y(jj), xmin, ymin, xmax, ymax);
                    [coords, dxdxi, d2xdxi2, dxdxi2] = paramMap3D( GIFTmesh{patchIndex},gauss_coord_x(ii), gauss_coord_y(jj), gauss_coord_z(kk), xmin, ymin, zmin, xmax, ymax, zmax);
                    
                    dR = dxdxi\[dRdx'; dRdy'; dRdz'];
                    ddR=[d2Rdx'; d2Rdxdy'; d2Rdy'; d2Rdxdz'; d2Rdydz'; d2Rdz'];
                    ddR = dxdxi2\(ddR - d2xdxi2*dR);
                    
                    J = abs(det(dxdxi));
                    
                    % Extract second derivatives
                     ddRx = ddR(1, :);
                     ddRy = ddR(3, :);
                     ddRz = ddR(6, :);
                    
                    % Compute 4th-order derivatives (example placeholders)
                        [~,~,d4udx4,d4udy4,d4udz4,d4udx2dy2,d4udx2dz2,d4udy2dz2]=computeDerivativesSquareWith2HolesBiharmonic(coords(1),coords(2));
                    
                        % Compute stiffness matrix contributions
                        part1 = ddRx' * (ddRx + ddRy + ddRz);
                        part2 = ddRy' * (ddRx + ddRy + ddRz);
                        part3 = ddRz' * (ddRx + ddRy + ddRz);
                    
                        tempValue = part1 + part2 + part3;
                        localStiff = localStiff + tempValue * scalefac * gauss_weight_x(ii) * gauss_weight_y(jj) * gauss_weight_z(kk) * J;
                    
                        % Compute RHS
                        f = d4udx4 + d4udy4 + d4udz4 + 2 * (d4udx2dy2 + d4udx2dz2 + d4udy2dz2);
                        localRhsTemp = R * f;
                        localRhsTemp = localRhsTemp .* scalefac .* gauss_weight_x(ii) .* gauss_weight_y(jj) .* gauss_weight_z(kk) .* J;
                        localRhs = localRhs + localRhsTemp;
                    end
                end
            end
            
            stiff(scrtx,scrtx) = stiff(scrtx,scrtx) + localStiff;
            rhs(scrtx) =  rhs(scrtx) + localRhs;
        end
    end
end

end