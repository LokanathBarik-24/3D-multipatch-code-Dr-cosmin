function [l2relerr] =calcErrorNormsBiharmonic_square3D(PHTelem, GIFTmesh,  p, q, r, sol0 )

disp('enter cal error')
numGaussX = p+1;
numGaussY = q+1;
numGaussZ = r+1;

[gwx, gpx]=quadrature(numGaussX, 'GAUSS', 1);
[gwy, gpy]=quadrature(numGaussY, 'GAUSS', 1);
[gwz, gpz]=quadrature(numGaussZ, 'GAUSS', 1);

gpx=gpx';
gpy=gpy';
gpz=gpz';

l2norm = 0;
l2relerr = 0;

%define the 2D Bernstein polynomials
[B_u, ~] = bernstein_basis(gpx,p);
[B_v, ~] = bernstein_basis(gpy,q);
[B_w, ~] = bernstein_basis(gpz,r);
Buvw = zeros(numGaussX, numGaussY, numGaussZ, (p+1)*(q+1)*(r+1));

basisCounter = 0;
for k=1:r+1
    for j=1:q+1
        for i=1:p+1
            basisCounter = basisCounter + 1;
            for kk=1:numGaussZ
                for jj=1:numGaussY
                    for ii=1:numGaussX
                        Buvw(ii,jj,kk,basisCounter) = B_u(ii,i)*B_v(jj,j)*B_w(kk,k);
                    end
                end
            end
        end
    end
end

for patchIndex = 1:length(PHTelem)
    for i=1:length(PHTelem{patchIndex})
        if isempty(PHTelem{patchIndex}(i).children)
            xmin = PHTelem{patchIndex}(i).vertex(1);
            xmax = PHTelem{patchIndex}(i).vertex(4);
            ymin = PHTelem{patchIndex}(i).vertex(2);
            ymax = PHTelem{patchIndex}(i).vertex(5);
            zmin = PHTelem{patchIndex}(i).vertex(3);
            zmax = PHTelem{patchIndex}(i).vertex(6);
            
            % Scale factor for the transformation
            scalefac = (xmax - xmin) * (ymax - ymin) * (zmax - zmin) / 8;
            
            globalNodes = PHTelem{patchIndex}(i).nodesGlobal;
            tempSol = sol0(globalNodes);
            
            for kk = 1:numGaussZ
                for jj = 1:numGaussY
                    for ii = 1:numGaussX
                        [coord, dxdxi] = paramMap(GIFTmesh{patchIndex}, gpx(ii), gpy(jj), gpz(kk), xmin, ymin, zmin, xmax, ymax, zmax);
                        
                        J = det(dxdxi);
                        R = (PHTelem{patchIndex}(i).modifiedC) * squeeze(Buvw(ii, jj, kk, :));
                        sol = R' * tempSol;
                        
                        % Exact solution: u_exact = x²(1-x)² * y²(1-y)² * z²(1-z)²
                        exactSol = coord(1)^2 * (1 - coord(1))^2 * coord(2)^2 * (1 - coord(2))^2 * coord(3)^2 * (1 - coord(3))^2;
                        
                        l2norm = l2norm + (exactSol^2) * gwx(ii) * gwy(jj) * gwz(kk) * scalefac * J;
                        l2relerr = l2relerr + ((exactSol - sol)^2) * gwx(ii) * gwy(jj) * gwz(kk) * scalefac * J;
                    end
                end
            end
        end
    end
end

% Compute relative L2 error
l2relerr = sqrt(l2relerr) / sqrt(l2norm);

disp(['L2 Relative Error: ', num2str(l2relerr)]);
end