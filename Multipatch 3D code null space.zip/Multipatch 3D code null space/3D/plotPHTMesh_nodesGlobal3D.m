function plotPHTMesh_nodesGlobal3D(PHUTelem, GIFTmesh, p)
% 3D visualization of global node numbers on PHT mesh
% Patch A - blue, Patch B - red, etc.

colorArray = {'blue', 'red', 'green', 'cyan', 'magenta', 'black'};
numPts = p+1; % points per direction
space = 0.3;
uref = linspace(-1+space, 1-space, numPts);
vref = linspace(-1+space, 1-space, numPts);
wref = linspace(-1+space, 1-space, numPts);

figure
hold on

for patchIndex = 1:length(PHUTelem)
    colorIndex = rem((patchIndex-1), 6) + 1;
    for elemIndex = 1:length(PHUTelem{patchIndex})
        if isempty(PHUTelem{patchIndex}(elemIndex).children)
            % Get physical domain bounding box
            vertex = PHUTelem{patchIndex}(elemIndex).vertex;
            xmin = vertex(1); ymin = vertex(2); zmin = vertex(3);
            xmax = vertex(4); ymax = vertex(5); zmax = vertex(6);
            
            count = 0;
            nodesGlobal = PHUTelem{patchIndex}(elemIndex).nodesGlobal;
            
            for kk = 1:numPts
                for jj = 1:numPts
                    for ii = 1:numPts
                        count = count + 1;
                        % Parametric coords
                        u = uref(ii); v = vref(jj); w = wref(kk);
                        
                        % Map to physical domain
                        coord = paramMap3D(GIFTmesh{patchIndex}, u, v, w, xmin, ymin, zmin, xmax, ymax, zmax);
                        
                        % Plot global node number as text
                        text(coord(1), coord(2), coord(3), num2str(nodesGlobal(count)), ...
                             'Color', colorArray{colorIndex}, 'FontSize', 10, 'HorizontalAlignment', 'center')
                    end
                end
            end
            
            % Optional: Draw wireframe box
            drawElementBox3D(xmin, xmax, ymin, ymax, zmin, zmax, colorArray{colorIndex});
        end
    end
end

xlabel('X'); ylabel('Y'); zlabel('Z');
title('3D PHT Mesh with Global Node Numbers')
axis equal
grid on
view(3)
drawnow
end
