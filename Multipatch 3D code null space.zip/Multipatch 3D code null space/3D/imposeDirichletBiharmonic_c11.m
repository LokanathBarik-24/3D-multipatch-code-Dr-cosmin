function [ stiff, rhs, bcdof, bcval] = imposeDirichletBiharmonic_c11(stiff, rhs, PHTelem, p, q ,r, numPatches,type2Basis)

%Face encoding: 1 - front, 2 - right, 3 - back, 4 - left, 5 - bottom, 6 - top
%detect which nodes have support on the left and right boundary
bcdof_left = [];
bcdof_right = [];
bcdof_up = [];
bcdof_down = [];
bcdof_front = [];
bcdof_back = [];

% Define face node indices

right_nodes = (p+1):(p+1):(p+1)*(q+1)*(r+1);
right_nodes2 = (p+1)-1:(p+1):(p+1)*(q+1)*(r+1)-1;

left_nodes = 1:(p+1):(p+1)*(q+1)*(r+1);
left_nodes2 = 2:(p+1):(p+1)*(q+1)*(r+1);

down_nodes=1:(p+1)*(q+1);
down_nodes2=down_nodes+(p+1)*(q+1);

up_nodes=(p+1)*(q+1)*(r)+1:(p+1)*(q+1)*(r+1);
up_nodes2=up_nodes-(p+1)*(q+1);

front_nodes=reshape((1:p+1)' + (0:r)*(p+1)*(q+1), 1, []);
front_nodes2=front_nodes+(p+1);

back_nodes=reshape((p*(q+1)+1:(p+1)*(q+1))' + (0:r)*(p+1)*(q+1), 1, []);
back_nodes2=back_nodes-(p+1);


%set the boundary degree of freedom and elements from the 1st patch
for indexPatch = 1:numPatches
    for i=1:length(PHTelem{indexPatch})
        if isempty(PHTelem{indexPatch}(i).children)
            
            % numBasis=length(PHTelem{indexPatch}(i).nodes);
            
            if isempty(PHTelem{indexPatch}(i).neighbor_right) 
                
                nodes=[right_nodes,right_nodes2];
                % nodes=right_nodes;
                
                for ii=1:length(nodes)

                        bcdof_right = [bcdof_right,PHTelem{indexPatch}(i).nodes(nodes(ii))];

                end
                
                % bcdof_right = [bcdof_right, PHTelem{indexPatch}(i).nodes(right_nodes),PHTelem{indexPatch}(i).nodes(right_nodes2)];
            end
            
            if isempty(PHTelem{indexPatch}(i).neighbor_down)
                
                nodes=[down_nodes,down_nodes2];
                % nodes=down_nodes;
                
                for ii=1:length(nodes)

                        bcdof_down = [bcdof_down,PHTelem{indexPatch}(i).nodes(nodes(ii))];

                end
                
                % bcdof_down = [bcdof_down, PHTelem{indexPatch}(i).nodes(down_nodes), PHTelem{indexPatch}(i).nodes(down_nodes2)];
            end
            
            if isempty(PHTelem{indexPatch}(i).neighbor_up)
                
                nodes=[up_nodes,up_nodes2];
                % nodes=up_nodes;
                
                for ii=1:length(nodes)

                        bcdof_up = [bcdof_up,PHTelem{indexPatch}(i).nodes(nodes(ii))];

                end
                
                %bcdof_up = [bcdof_up, PHTelem{indexPatch}(i).nodes(up_nodes),PHTelem{indexPatch}(i).nodes(up_nodes2)];
            end

            if isempty(PHTelem{indexPatch}(i).neighbor_front)
                
                nodes=[front_nodes,front_nodes2];
                % nodes=front_nodes;
                
                for ii=1:length(nodes)

                        bcdof_front = [bcdof_front,PHTelem{indexPatch}(i).nodes(nodes(ii))];

                end
                
                % bcdof_front = [bcdof_front, PHTelem{indexPatch}(i).nodes(front_nodes), PHTelem{indexPatch}(i).nodes(front_nodes2)];
            end

            if isempty(PHTelem{indexPatch}(i).neighbor_back)
                
                nodes=[back_nodes,back_nodes2];
                % nodes=back_nodes;
                
                for ii=1:length(nodes)

                        bcdof_back = [bcdof_back,PHTelem{indexPatch}(i).nodes(nodes(ii))];

                end
                
                % bcdof_back = [bcdof_back, PHTelem{indexPatch}(i).nodes(back_nodes), PHTelem{indexPatch}(i).nodes(back_nodes2)];
            end
            
            if isempty(PHTelem{indexPatch}(i).neighbor_left)
                
                nodes=[left_nodes,left_nodes2];
                % nodes=left_nodes;
                
                for ii=1:length(nodes)

                        bcdof_left = [bcdof_left,PHTelem{indexPatch}(i).nodes(nodes(ii))];

                end
                
                %bcdof_left = [bcdof_left, PHTelem{indexPatch}(i).nodes(left_nodes),PHTelem{indexPatch}(i).nodes(left_nodes2)];
            end
        end
    end
end


bcdof = unique([bcdof_down, bcdof_up, bcdof_left, bcdof_right, bcdof_front, bcdof_back]);

bcval = zeros(size(bcdof));

% temp_bcdof_right=2*bcdof_right-1;
% temp_bcdof_down=2*bcdof_down;
% temp_bcdof_up=2*bcdof_up;
% temp_bcdof_left=2*bcdof_left-1;

%bcdof = [temp_bcdof_right,temp_bcdof_down,temp_bcdof_up,temp_bcdof_left];
% bcdof = unique([bcdof_down, bcdof_up, bcdof_left, bcdof_right]);
% bcval = zeros(size(bcdof));

[stiff,rhs]=feaplyc2sym(stiff, rhs, bcdof, bcval);
end

