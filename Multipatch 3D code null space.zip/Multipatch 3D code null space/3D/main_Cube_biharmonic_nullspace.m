restoredefaultpath
% close all
clear all
addpaths

tic;

numPatches = 2;
W = 1;
L = 1;
H = 1;
GIFTmesh = init2DGeometryGIFTMP('rectangle', L, W, H, numPatches);
% GIFTmesh = init2DGeometryGIFTMP('2patch_curvedCommonBoundary', L, W, H, numPatches);

p=3;
q=p;
r=p;

numElemU=2;
numElemV=numElemU;
numElemW=numElemU;

PHUTelem = cell(numPatches, 1);
dimBasis = zeros(1, numPatches);
quadList = cell(numPatches, 1);

if p==2
    for indexPatch=1:numPatches
        [PHUTelem{indexPatch}, dimBasis(indexPatch), lenVec] = initPHTmesh_quadratic( p,q,r,numElemU,numElemV,numElemW);
        numElem=length(PHUTelem{indexPatch});
        quadList{indexPatch} =1:numElem;
    end
else
    for indexPatch=1:numPatches
        [PHUTelem{indexPatch}, dimBasis(indexPatch), lenVec] = initPHTmeshGen( p,q,r,numElemU,numElemV,numElemW);
        numElem=length(PHUTelem{indexPatch});
        quadList{indexPatch} =1:numElem;
    end
end

%Face encoding: 1 - front, 2 - right, 3 - back, 4 - left, 5 - bottom, 6 - top

patchBoundaries = {1,2,2,4};

numSteps = 3;

for stepCount = 1:numSteps


    
    %subject to error if found
    [PHUTelem,  sizeBasis ] = zipConformingNew( PHUTelem, dimBasis, patchBoundaries, p, q, r);  
    
    disp('assign sol Index')
    [PHUTelem,solIndexCount] = assignSolIndex2D_quadratic(PHUTelem,patchBoundaries,sizeBasis,p,q,r);
    
    disp('compute matrix m')
    [PHUTelem,m] = zipConformingC1_quadratic(PHUTelem,GIFTmesh,patchBoundaries,solIndexCount,p,q,r,lenVec,numElemW);
    % test_sol = [test_sol,test_sol([3,2,1],:)];
    
   % [PHUTelem,m] =zipConformingC1_method3(PHUTelem,GIFTmesh,patchBoundaries,solIndexCount,p,q);
    disp('apply boundary condition')
    [coefSol] = zipConformingC1_p2_BC_2patchSquareBiharmonic_null(PHUTelem,m,p,q,r);
    % [coefSol] = zipConformingC1_p2_BC_2patchSquaretest_null(PHUTelem,m,p,q,r);
    
    disp('assign new nodes global and modify c')
    [PHUTelem,sizeBasis,type2Basis] = zipConformingC1_quaddratic_modifyC(PHUTelem,GIFTmesh,patchBoundaries,sizeBasis,coefSol,solIndexCount,p,q,r);
    
    %     figure
    %     plotPHTMesh_solIndex( PHUTelem,GIFTmesh,p)
    %     plotPHTMesh_solIndex1( PHUTelem,GIFTmesh,p)
    %     title('sol Index')
    %     pause
    %
    %     figure
    %     plotPHTMesh_nodesGlobal1( PHUTelem,GIFTmesh,p)
    %     plotPHTMesh_nodesGlobal( PHUTelem,GIFTmesh,p)
    %     title('nodes Global')
    %     pause
    
    disp('localising type 2 basis function')
    [PHUTelem] = localizeType2Basis2(PHUTelem,type2Basis);
    %testPlotBasisPhys_GIFTmesh3( PHUTelem,GIFTmesh,p,q,3)
    %testPlotBasisPhys_GIFTmesh(PHUTelem,GIFTmesh,p,q,type2Basis)
    
    %testPlotBasisPhys_GIFTmesh(PHUTelem,GIFTmesh,p,q,type2Basis)
    
    %     for i=1:sizeBasis
    %         testPlotBasisPhys_GIFTmesh3(PHUTelem,GIFTmesh,p,q,i)
    %         pause
    %         close all
    %     end
    
    % Emod=1e5;
    % nu=0;
    % Cmat = zeros(6);
    % Cmat(1:3,1:3) = Emod/((1+nu)*(1-2*nu))*[1-nu, nu, nu; nu, 1-nu, nu; nu, nu, 1-nu];
    % Cmat(4:6,4:6) = Emod/(1+nu)*eye(3);
    % bound_disp = 0.1;
    
    disp('Assembling the linear system...')
    % [stiff,rhs] = assembleBiharmonic_c1_3(PHUTelem,GIFTmesh,sizeBasis,p,q,r);
    [stiff,rhs] = assembleBiharmonic_c1_3D(PHUTelem,GIFTmesh,sizeBasis,p,q,r);
    
    disp('Imposing boundary conditions...')
    [ stiff, rhs, bcdof, bcval] = imposeDirichletBiharmonic_c1(stiff, rhs, PHUTelem, p, q ,r, numPatches,type2Basis);
    
    disp('Solving the linear system...')
    sol0 = stiff\rhs;
    
    vtuFile = ['BiharmonicCubeSol',num2str(stepCount),'.vtu'];
    plotStressDisp3DVM_20pt(PHUTelem, GIFTmesh, sol0, p, q, r, vtuFile, 0.75)
    % plotStressDisp3DVM_20pt(PHUTelem, GIFTmesh, sol0, p, q, r, vtuFile, 0.75)
    
    
    %got the figure
    % figure
    % PlotDispPlate_c1(PHUTelem, GIFTmesh,  p, q, r, sol0);
    % % axis equal
    
    size(sol0)
    [l2relerr] = calcErrorNormsBiharmonic_square3D(PHUTelem, GIFTmesh,  p, q, r, sol0)
    % [h1relerr,h2relerr] = cal_H1_H2_square(PHUTelem, GIFTmesh,  p, q, sol0 )
    % h1_err1(stepCount)=h1relerr;
    % h2_err1(stepCount)=h2relerr;
    l2err1(stepCount) = l2relerr;
    dof1(stepCount) = sizeBasis;
    
            %%%%%%%%%%%%%%%%%%%%% refinement %%%%%%%%%%%%%%%%%%%%
    if stepCount<numSteps
        numElemU=numElemU*2;
        numElemV=numElemV*2;
        numElemW=numElemW*2;
        for indexPatch=1:numPatches
            if p==2
                [PHUTelem{indexPatch}, dimBasis(indexPatch), lenVec] = initPHTmesh_quadratic( p,q,r,numElemU,numElemV,numElemW);
            else
                [PHUTelem{indexPatch}, dimBasis(indexPatch), lenVec] = initPHTmeshGen( p,q,r,numElemU,numElemV,numElemW);
            end
            numElem=length(PHUTelem{1});
            quadList{indexPatch} =1:numElem;
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
    
%%

% % figure(1)
% hold on
h1=loglog(dof1, l2err1, '--mo' , 'MarkerSize', 6, 'LineWidth', 2);
hold on
