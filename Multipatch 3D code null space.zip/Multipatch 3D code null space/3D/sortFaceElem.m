function [ elements ] = sortFaceElem( PHTelem, face)
%outputs the nodes and element along the given edge, sorted in the order in
%which they appear in the parameter space
% Face encoding: 1 - front, 2 - right, 3 - back, 4 - left, 5 - down, 6 - up

numEdges = length(face);
elements = cell(1, numEdges);

%initiialize array to store the corners of the edge elements and the edge element indices,
%for sorting purposes
verticesDown = [];
verticesRight = [];
verticesUp = [];
verticesLeft = [];
verticesFront = [];
verticesBack = [];

for elemIndex = 1:length(PHTelem)
    if isempty(PHTelem(elemIndex).children)
        for faceIndex = 1:numEdges
            
            % Front face (y = 0)
            if (face(faceIndex) == 1) && isempty(PHTelem(elemIndex).neighbor_front)
                elements{faceIndex} = [elements{faceIndex}, elemIndex];
                verticesFront = [verticesFront, PHTelem(elemIndex).vertex(1)];
            end
            
            % Right face (x = 1)
            if (face(faceIndex) == 2) && isempty(PHTelem(elemIndex).neighbor_right)
                elements{faceIndex} = [elements{faceIndex}, elemIndex];
                verticesRight = [verticesRight, PHTelem(elemIndex).vertex(2)];
            end
            
            % Back face (y = 1)
            if (face(faceIndex) == 3) && isempty(PHTelem(elemIndex).neighbor_back)
                elements{faceIndex} = [elements{faceIndex}, elemIndex];
                verticesBack = [verticesBack, PHTelem(elemIndex).vertex(1)];
            end
            
            % Left face (x = 0)
            if (face(faceIndex) == 4) && isempty(PHTelem(elemIndex).neighbor_left)
                elements{faceIndex} = [elements{faceIndex}, elemIndex];
                verticesLeft = [verticesLeft, PHTelem(elemIndex).vertex(2)];
            end
            
            % Bottom face (z = 0)
            if (face(faceIndex) == 5) && isempty(PHTelem(elemIndex).neighbor_down)
                elements{faceIndex} = [elements{faceIndex}, elemIndex];
                verticesDown = [verticesDown, PHTelem(elemIndex).vertex(1)];
            end
            
            % Top face (z = 1)
            if (face(faceIndex) == 6) && isempty(PHTelem(elemIndex).neighbor_up)
                elements{faceIndex} = [elements{faceIndex}, elemIndex];
                verticesUp = [verticesUp, PHTelem(elemIndex).vertex(1)];
            end
        end
    end
end


%sort the elements according to vertex location
for faceIndex=1:numEdges
    if (face(faceIndex) == 1)
        [verticesFront, indexSort] = sort(verticesFront);
        %rearrange the elements according to the sorting oder
        elements{faceIndex} = elements{faceIndex}(indexSort); 
    end
    
    if (face(faceIndex) == 2)
        [verticesRight, indexSort] = sort(verticesRight);
        %rearrange the elements according to the sorting oder
        elements{faceIndex} = elements{faceIndex}(indexSort); 
    end

     if (face(faceIndex) == 3)
        [verticesBack, indexSort] = sort(verticesBack);
        %rearrange the elements according to the sorting oder
        elements{faceIndex} = elements{faceIndex}(indexSort); 
    end
    
    if (face(faceIndex) == 4)
        [verticesLeft, indexSort] = sort(verticesLeft);
        %rearrange the elements according to the sorting oder
        elements{faceIndex} = elements{faceIndex}(indexSort); 
    end
    
    if (face(faceIndex) == 5)
        [verticesDown, indexSort] = sort(verticesDown);
        %rearrange the elements according to the sorting oder
        elements{faceIndex} = elements{faceIndex}(indexSort); 
    end
    
    if (face(faceIndex) == 6)
        [verticesUp, indexSort] = sort(verticesUp);        
        %rearrange the elements according to the sorting oder
        elements{faceIndex} = elements{faceIndex}(indexSort); 
    end

end





