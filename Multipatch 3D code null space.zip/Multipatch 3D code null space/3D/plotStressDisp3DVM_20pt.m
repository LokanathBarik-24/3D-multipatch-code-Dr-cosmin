function plotStressDisp3DVM_20pt(PHTelem, GIFTmesh, sol0, p, q, r, vtuFile, edgeSpace)
%plots the computed solution using quadartic (20 node) hexahedra
%supports multipatches

numPlotX = 3;
numPlotY = 3;
numPlotZ = 3;

if nargin<9
    edgeSpace = 1e-3; %space between the plot cell and the true element boundary
end

noGpEle = 20;

%calculate the number of actual elements (i.e., non-refined, without children)
numElem = 0;
for patchIndex=1:length(PHTelem)
    for i=1:length(PHTelem{patchIndex})
        if isempty(PHTelem{patchIndex}(i).children)
            numElem = numElem+1;
        end
    end
end


noElems =  numElem;
x     = zeros(3,noGpEle,noElems);  % global coords at Gauss points
u     = zeros(3,noGpEle,noElems);  % displacements at Gauss points

plotPtsX = linspace(-1+edgeSpace,1-edgeSpace,numPlotX);
plotPtsY = linspace(-1+edgeSpace,1-edgeSpace,numPlotY);
plotPtsZ = linspace(-1+edgeSpace,1-edgeSpace,numPlotZ);

%1D bernstein polynomials evaluated at the Gauss points on the master element
[B_u, dB_u] = bernstein_basis(plotPtsX,p);
[B_v, dB_v] = bernstein_basis(plotPtsY,q);
[B_w, dB_w] = bernstein_basis(plotPtsZ,r);

B_uvw = zeros(numPlotX, numPlotY, numPlotZ, (p+1)*(q+1)*(r+1));
dBdu = zeros(numPlotX, numPlotY, numPlotZ, (p+1)*(q+1)*(r+1));
dBdv = zeros(numPlotX, numPlotY, numPlotZ, (p+1)*(q+1)*(r+1));
dBdw = zeros(numPlotX, numPlotY, numPlotZ, (p+1)*(q+1)*(r+1));

%compute the function values and derivatives of the 3D Bernstein polynomials at plot points on the
%master element
basisCounter = 0;
for k=1:r+1
    for j=1:q+1
        for i=1:p+1
            basisCounter = basisCounter + 1;
            for kk=1:numPlotZ
                for jj=1:numPlotY
                    for ii=1:numPlotX
                        B_uvw(ii,jj,kk,basisCounter) = B_u(ii,i)*B_v(jj,j)*B_w(kk,k);
                        dBdu(ii,jj,kk,basisCounter) = dB_u(ii,i)*B_v(jj,j)*B_w(kk,k);
                        dBdv(ii,jj,kk,basisCounter) = B_u(ii,i)*dB_v(jj,j)*B_w(kk,k);
                        dBdw(ii,jj,kk,basisCounter) = B_u(ii,i)*B_v(jj,j)*dB_w(kk,k);
                    end
                end
            end
        end
    end
end

e = 1;

list_ijk = [1,1,1;2,1,1;3,1,1;1,2,1;3,2,1;1,3,1;2,3,1;3,3,1;1,1,2;3,1,2;1,3,2;3,3,2;1,1,3;2,1,3;3,1,3;1,2,3;3,2,3;1,3,3;2,3,3;3,3,3];

for patchIndex = 1:length(PHTelem)
    
    for i=1:length(PHTelem{patchIndex})
        if isempty(PHTelem{patchIndex}(i).children)
            xmin = PHTelem{patchIndex}(i).vertex(1);
            xmax = PHTelem{patchIndex}(i).vertex(4);
            ymin = PHTelem{patchIndex}(i).vertex(2);
            ymax = PHTelem{patchIndex}(i).vertex(5);
            zmin = PHTelem{patchIndex}(i).vertex(3);
            zmax = PHTelem{patchIndex}(i).vertex(6);
            
            globalNodes=PHTelem{patchIndex}(i).nodesGlobal;
            tempDisp=sol0(globalNodes);
            gp = 1;

            
            for listIndex = 1:size(list_ijk,1)
                ii = list_ijk(listIndex,1);
                jj = list_ijk(listIndex,2);
                kk = list_ijk(listIndex,3);
                
                [coord, dxdxi] = paramMap3D( GIFTmesh{patchIndex}, plotPtsX(ii), plotPtsY(jj), plotPtsZ(kk), xmin, ymin, zmin, xmax, ymax, zmax);
                
                cR = PHTelem{patchIndex}(i).modifiedC * squeeze(B_uvw(ii,jj,kk,:));
                
                
                %calculate displacement values

                disp_z = cR'*tempDisp;

                
                x(1,gp,e)     = coord(1);
                x(2,gp,e)     = coord(2);
                x(3,gp,e)     = coord(3);
                
                u(1,gp,e)     = disp_z;
                
                gp = gp +1 ;
                
            end
            e = e + 1;
            
        end
    end
end
% msh_to_vtu_3dVM_20points(x, u, [],[], [numPlotX numPlotY numPlotZ], vtuFile);
msh_to_vtu_3dVM_20points(x, u, [],[], [numPlotX numPlotY numPlotZ], vtuFile);