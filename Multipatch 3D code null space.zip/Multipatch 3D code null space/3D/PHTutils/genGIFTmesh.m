function [ GIFTmesh] = genGIFTmesh( knotU, knotV, knotW, coefs, p, q,r,  numberElementsU, numberElementsV, numberElementsW )
%generates a GIFTmesh object from the knot vectors, control points/weights
%and polynomial degrees given
%uses the same format as NURBS toolbox

dim = 3; %number of physical dimensions

%tolerance for equality tests
toleq = 1e-10;

%the number of control points in the u and v directions
lenU = length(knotU)-p-1;  %number of basis functions in the u direction
lenV = length(knotV)-q-1;  %number of basis functions in the v direction
lenW = length(knotW)-r-1;  %number of basis functions in the w direction
numnodes = lenU*lenV*lenW;      %number of control points
coordinates = zeros(numnodes, dim+1);  %allocate one more column for the weights

for k = 1:lenW % for each node in the z direction
    for j = 1:lenV % for each node in the y direction
        for i = 1:lenU % for each node in the x direction
            index = (k-1)*lenU*lenV + (j-1)*lenU + i; % the index of the coordinate array
            coordinates(index,:) = [ ...
                coefs(1,i,j,k) / coefs(4,i,j,k), ... % X-coordinate
                coefs(2,i,j,k) / coefs(4,i,j,k), ... % Y-coordinate
                coefs(3,i,j,k) / coefs(4,i,j,k), coefs(4,i,j,k)];    % Z-coordinate
        end % for i
    end % for j
end % for k

% Initialize Bezier extraction operator for 3D
C = zeros((p+1)*(q+1)*(r+1), (p+1)*(q+1)*(r+1), numberElementsU*numberElementsV*numberElementsW);

% Perform Bezier extraction in each parametric direction
[C_u, ~] = bezierExtraction(knotU, p); % U-direction
[C_v, ~] = bezierExtraction(knotV, q); % V-direction
[C_w, ~] = bezierExtraction(knotW, r); % W-direction

% Construct 3D Bezier extraction operators
elementIndex = 0;
for k = 1:numberElementsW
    for j = 1:numberElementsV
        for i = 1:numberElementsU
            elementIndex = elementIndex + 1;
            C(:,:,elementIndex) = kron(C_w(:,:,k), kron(C_v(:,:,j), C_u(:,:,i))); % Tensor product
        end
    end
end

elementCounter = 0;
elementVertex = zeros(numberElementsU * numberElementsV * numberElementsW, 6); % For 3D: 6 corners per element (min/max in U, V, W)
elementNode = zeros(numberElementsU * numberElementsV * numberElementsW, (p+1)*(q+1)*(r+1));

for k = 1:length(knotW)-1
    for j = 1:length(knotV)-1
        for i = 1:length(knotU)-1
            if (abs(knotU(i+1)-knotU(i)) > toleq) && ...
               (abs(knotV(j+1)-knotV(j)) > toleq) && ...
               (abs(knotW(k+1)-knotW(k)) > toleq)
                elementCounter = elementCounter + 1;

                % Define the vertices of the element in 3D
                elementVertex(elementCounter, :) = [knotU(i), knotV(j), knotW(k), ...
                                                     knotU(i+1), knotV(j+1), knotW(k+1)];

                tcount = 0;
                currow = zeros(1, (p+1)*(q+1)*(r+1));

                % Add nodes from i-p:i in U, j-q:j in V, k-r:k in W
                for t3 = k-r:k
                    for t2 = j-q:j
                        for t1 = i-p:i
                            tcount = tcount + 1;
                            currow(tcount) = t1 + (t2-1)*lenU + (t3-1)*lenU*lenV;
                        end
                    end
                end
                elementNode(elementCounter, :) = currow;
            end
        end
    end
end

% Store data in GIFTmesh structure
GIFTmesh.numberElements = numberElementsU * numberElementsV * numberElementsW;
GIFTmesh.numberElementsU = numberElementsU;
GIFTmesh.numberElementsV = numberElementsV;
GIFTmesh.numberElementsW = numberElementsW;

GIFTmesh.p = p;
GIFTmesh.q = q;
GIFTmesh.r = r;
GIFTmesh.c_net = coordinates;
GIFTmesh.C = C;
GIFTmesh.elementNode = elementNode;
GIFTmesh.elementVertex = elementVertex;

