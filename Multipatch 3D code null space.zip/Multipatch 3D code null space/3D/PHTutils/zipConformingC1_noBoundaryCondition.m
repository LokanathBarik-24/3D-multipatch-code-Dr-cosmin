function [ coefSol ] = zipConformingC1_noBoundaryCondition( PHUTelem,m,p,q )

coefSol = nullMDS(m);