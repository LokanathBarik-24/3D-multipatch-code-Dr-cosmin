function [ coefSol ] = zipConformingC1_boundaryCondition_bilinearPatch_patchTest( PHUTelem,m,p,q )
coefSol = nullMDS(m);
end


