function [PHUTelem,m] =zipConformingC1_quadratic(PHUTelem,GIFTmesh,patchBoundaries,solIndexCount,p,q,r,lenVec,numElemW)

[boundaryInfo,segInfo,~,~,patchNeighborInfo,patchEdgeInfo] = createBoundaryInfo3(PHUTelem, patchBoundaries );

numSeg=size(segInfo,1);

numBoundaries = size(patchBoundaries,1);

numColumns=solIndexCount;
numPtsU = ceil(sqrt(numColumns / numSeg));
numPtsV = ceil(numColumns / (numSeg * numPtsU));


if numPtsU < p+1
    numPtsU = p+1;
end
if numPtsV < q+1
    numPtsV = q+1;
end

m=zeros(numSeg * numPtsU * numPtsV, numColumns); %retrive original (numPts*numSeg,numColumns)
i=0; 

for boundaryIndex = 1:numBoundaries
    patchAList = patchBoundaries(boundaryIndex,1);
    patchB = patchBoundaries(boundaryIndex,2);
    edgeAList = patchBoundaries(boundaryIndex,3);
    edgeBList = patchBoundaries(boundaryIndex,4);
    
    edgeAList=cell2mat(edgeAList);
    edgeBList=cell2mat(edgeBList);
    
    patchAList=cell2mat(patchAList);
    patchB=cell2mat(patchB);
    
    for indexPatch=1:length(patchAList)
        patchA = patchAList(indexPatch);
        edgeA = edgeAList(indexPatch);
        edgeB = edgeBList(indexPatch);
        
        [elemA] = sortFaceElem( PHUTelem{patchA}, edgeA);
        [elemB] = sortFaceElem( PHUTelem{patchB}, edgeB);
        
        % elemA=elemA{1};
        % elemB=elemB{1};

        elemA=sort(elemA{1});
        elemB=sort(elemB{1});
        
        patchInfo.patchA=patchA;
        patchInfo.patchB=patchB;
        patchInfo.edgeA=edgeA;
        patchInfo.edgeB=edgeB;
        patchInfo.elemA=elemA;
        patchInfo.elemB=elemB;
        
        [m,i] = computeMatrixM_method2(PHUTelem,GIFTmesh,patchInfo,m,i,p,q,r,numPtsU,numPtsV);
    end
    
end

end

