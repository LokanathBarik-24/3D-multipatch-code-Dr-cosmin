function [a,b,c,d] = computeFunctionABC_GIFTmesh_vDirection(PHUTelem,GIFTmesh,patchA,elemA,patchB,elemB,refPoint)

xmin = PHUTelem{patchA}(elemA).vertex(1);
xmax = PHUTelem{patchA}(elemA).vertex(4);
ymin = PHUTelem{patchA}(elemA).vertex(2);
ymax = PHUTelem{patchA}(elemA).vertex(5);
zmin = PHUTelem{patchA}(elemA).vertex(3);
zmax = PHUTelem{patchA}(elemA).vertex(6);

urefA=refPoint.urefA;
vrefA=refPoint.vrefA;
wrefA=refPoint.wrefA;
urefB=refPoint.urefB;
vrefB=refPoint.vrefB;
wrefB=refPoint.wrefB;


[coord, dxdxi] = paramMap( GIFTmesh{patchA}, urefA, vrefA, wrefA, xmin, ymin, zmin, xmax, ymax, zmax );
 plot(coord(1),coord(2),'+r')
 hold on

dGdx_Patch1=dxdxi(1,:);
dGdy_Patch1=dxdxi(2,:);
dGdz_Patch1=dxdxi(3,:);

xmin = PHUTelem{patchA}(elemA).vertex(1);
xmax = PHUTelem{patchA}(elemA).vertex(4);
ymin = PHUTelem{patchA}(elemA).vertex(2);
ymax = PHUTelem{patchA}(elemA).vertex(5);
zmin = PHUTelem{patchA}(elemA).vertex(3);
zmax = PHUTelem{patchA}(elemA).vertex(6);

[coord, dxdxi] = paramMap( GIFTmesh{patchB}, urefB, vrefB, wrefB, xmin, ymin, zmin, xmax, ymax, zmax );
 plot(coord(1),coord(2),'.k')
 hold on
% pause

dGdy_Patch2=dxdxi(2,:);

a= det([dGdy_Patch1(1) dGdz_Patch1(1) dGdy_Patch2(1); ...
       dGdy_Patch1(2) dGdz_Patch1(2) dGdy_Patch2(2); ...
       dGdy_Patch1(3) dGdz_Patch1(3) dGdy_Patch2(3);]);

b=-det([dGdx_Patch1(1) dGdz_Patch1(1) dGdy_Patch2(1); ...
        dGdx_Patch1(2) dGdz_Patch1(2) dGdy_Patch2(2); ...
        dGdx_Patch1(3) dGdz_Patch1(3) dGdy_Patch2(3);]);

c=det([dGdx_Patch1(1) dGdy_Patch1(1) dGdy_Patch2(1); ...
        dGdx_Patch1(2) dGdy_Patch1(2) dGdy_Patch2(2); ...
        dGdx_Patch1(3) dGdy_Patch1(3) dGdy_Patch2(3);]);

d= -det([dGdx_Patch1(1) dGdy_Patch1(1) dGdz_Patch1(1); ...
        dGdx_Patch1(2) dGdy_Patch1(2) dGdz_Patch1(2); ...
        dGdx_Patch1(3) dGdy_Patch1(3) dGdz_Patch1(3);]);

end

