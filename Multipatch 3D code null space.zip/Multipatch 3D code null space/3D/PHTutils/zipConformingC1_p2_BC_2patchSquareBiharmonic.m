function [coefSol] = zipConformingC1_p2_BC_2patchSquareBiharmonic( PHUTelem,m,p,q,r, test_sol,numElemV )

% Face encoding: 1 - front, 2 - right, 3 - back, 4 - left, 5 - down, 6 - up
right_nodes1 = (p+1):(p+1):(p+1)*(q+1)*(r+1);
right_nodes2 = (p+1)-1:(p+1):(p+1)*(q+1)*(r+1)-1;

left_nodes1 = 1:(p+1):(p+1)*(q+1)*(r+1);
left_nodes2 = 2:(p+1):(p+1)*(q+1)*(r+1);

down_nodes1=1:(p+1)*(q+1);
down_nodes2=down_nodes1+(p+1)*(q+1);

up_nodes1=(p+1)*(q+1)*(r)+1:(p+1)*(q+1)*(r+1);
up_nodes2=up_nodes1-(p+1)*(q+1);

front_nodes1=reshape((1:p+1)' + (0:r)*(p+1)*(q+1), 1, []);
front_nodes2=front_nodes1+(p+1);

back_nodes1=reshape((p*(q+1)+1:(p+1)*(q+1))' + (0:r)*(p+1)*(q+1), 1, []);
back_nodes2=back_nodes1-(p+1);

%======================= apply boundary condition =========================
% elemPatch1 = sortEdgeElem( PHUTelem{1}, 2);
% elemPatch2 = sortEdgeElem( PHUTelem{2}, 4);
% elemPatch1=cell2mat(elemPatch1);
% elemPatch2=cell2mat(elemPatch2);
% 
% elemUpPatch1=elemPatch1(end-numElemV+1:end);
% elemDownPatch1=elemPatch1(1:numElemV);
% 
% elemUpPatch2=elemPatch2(end-numElemV+1:end);
% elemDownPatch2=elemPatch2(1:numElemV);
% 
list=[];
% % list=[list,PHUTelem{1}(elemUpPatch1).solIndex(up_nodes1)];
% % list=[list,PHUTelem{2}(elemUpPatch2).solIndex(up_nodes1)];
% % list=[list,PHUTelem{1}(elemDownPatch1).solIndex(down_nodes1)];
% % list=[list,PHUTelem{2}(elemDownPatch2).solIndex(down_nodes1)];
% 
% list=[list,PHUTelem{1}(elemUpPatch1).solIndex(up_nodes1),PHUTelem{1}(elemUpPatch1).solIndex(up_nodes2)];
% list=[list,PHUTelem{2}(elemUpPatch2).solIndex(up_nodes1),PHUTelem{2}(elemUpPatch2).solIndex(up_nodes2)];
% list=[list,PHUTelem{1}(elemDownPatch1).solIndex(down_nodes1),PHUTelem{1}(elemDownPatch1).solIndex(down_nodes2)];
% list=[list,PHUTelem{2}(elemDownPatch2).solIndex(down_nodes1),PHUTelem{2}(elemDownPatch2).solIndex(down_nodes2)];

nodesRight=[right_nodes1, right_nodes2];
nodesLeft=[left_nodes1, left_nodes2];
nodesUp=[up_nodes1, up_nodes2];
nodesDown=[down_nodes1, down_nodes2];
nodesFront=[front_nodes1, front_nodes2];
nodesBack=[back_nodes1, back_nodes2];

indexPatch=1;
for indexElem=1:length(PHUTelem{indexPatch})
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_up)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(nodesUp)];
    end
    
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_down)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(nodesDown)];
    end

    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_front)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(nodesFront)];
    end
    
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_back)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(nodesBack)];
    end
 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

indexPatch=2;
for indexElem=1:length(PHUTelem{indexPatch})
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_up)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(nodesUp)];
    end
    
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_down)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(nodesDown)];
    end

    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_front)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(nodesFront)];
    end
    
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_back)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(nodesBack)];
    end
 
end

list=nonzeros(list);
list=unique(list);

% list=[];

%loop to nullify the boundary solindex and remove in our analysis
for i=1:length(list)
    [a,b]=find(test_sol==list(i));
    test_sol(:,b)=[];
end


% test_sol(:,[1,end])=[];
temp=unique(test_sol', 'rows')';
temp=[temp,temp([3,2,1],:)];
% temp1(1,:)=temp(1,:);
% temp1(2,:)=temp(3,:);



% for i=1:length(temp1)
% [a,b]=find(test_sol==temp1(i));
% if a(1,1)==1
%     temp(2,i)=test_sol(3,b(1,1));
% elseif a(1,1)==2
%     temp(2,i)=test_sol(2,b(1,1));
% else
%     temp(2,i)=test_sol(1,b(1,1));
% end
% end

% determine the removed sequence for substitution 
rel=setdiff(1:size(m, 2), list);
m(:,list) = [];

% Initialize a zero matrix with the same number of rows and columns as the desired order
temp1 = zeros(size(temp, 1), length(rel));

% Find the column indices of the elements in desired order that exist in the matrix
[is_present, indices] = ismember(rel, temp(1, :));

% Populate the reordered matrix
temp1(:, is_present) = temp(:, indices(is_present));

% tempCoefSol = nullMDS_old(m);

tempCoefSol = nullMDS(m,temp1);

%add rows of zeros
coefSol=zeros(size(tempCoefSol,1)+length(list),size(tempCoefSol,2));
count=0;
for indexRow=1:size(coefSol,1)
    if  ~ismember(indexRow,list)
        count=count+1;
        coefSol(indexRow,:)=tempCoefSol(count,:);
    end
end
%coefSol = nullMDS(m);

end

