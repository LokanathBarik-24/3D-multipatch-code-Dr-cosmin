function [m,i,test_sol] = computeMatrixM_method2(PHUTelem,GIFTmesh,patchInfo,m,i,p,q,r,numPtsU,numPtsV)
% Face encoding: 1 - front, 2 - right, 3 - back, 4 - left, 5 - down, 6 - up

fudge=0.1;

patchA=patchInfo.patchA;
patchB=patchInfo.patchB;
edgeA=patchInfo.edgeA;
edgeB=patchInfo.edgeB;
elemA=patchInfo.elemA;
elemB=patchInfo.elemB;


[nodesA,midNodesA,nodesB,midNodesB] = selectSolIndexNodesAndBasisNodes(edgeA,edgeB,p,q,r);

%dealing with segments in the main boundary
%disp('dealing with segments in main boundary')
for indexSeg=1:length(elemA)
    
    solIndex=[PHUTelem{patchA}(elemA(indexSeg)).solIndex(nodesA);...
        PHUTelem{patchA}(elemA(indexSeg)).solIndex(midNodesA);...
        PHUTelem{patchB}(elemB(indexSeg)).solIndex(nodesB)];
    
    basisIndex=[nodesA;midNodesA;midNodesB;nodesB];

        testV1 = ismember(edgeA, [1,3]) && ismember(edgeB, [1,3]); % Both faces are aligned in V-direction
        testV2 = ismember(edgeA, [2,4]) && ismember(edgeB, [1,3]); % U-V interaction
        testV3 = ismember(edgeA, [5,6]) && ismember(edgeB, [1,3]); % V-W interaction
        
        testW1 = ismember(edgeA, [5,6]) && ismember(edgeB, [5,6]); % Both faces are aligned in W-direction
        testW2 = ismember(edgeA, [2,4]) && ismember(edgeB, [5,6]); % U-W interaction
        testW3 = ismember(edgeA, [1,3]) && ismember(edgeB, [5,6]); % W-V interaction
        
        testU1 = ismember(edgeA, [2,4]) && ismember(edgeB, [2,4]); % Both faces are aligned in U-direction
        testU2 = ismember(edgeA, [5,6]) && ismember(edgeB, [2,4]); % V-U interaction
        testU3 = ismember(edgeA, [1,3]) && ismember(edgeB, [2,4]); % W-U interaction
    
    %main boundary
    for iv=1:numPtsV
        for iu=1:numPtsU
    
            if testV1 || testV2 || testV3

                wref = linspace(-1+fudge,1-fudge,numPtsV);
                vref = [];
                uref = linspace(-1+fudge,1-fudge,numPtsU);

                [refPoint] = assignRefPoint3D(iu,iv,uref,vref,wref,edgeA,edgeB);
                    
                urefA=refPoint.urefA;
                vrefA=refPoint.vrefA;
                wrefA=refPoint.wrefA;
                urefB=refPoint.urefB;
                vrefB=refPoint.vrefB;
                wrefB=refPoint.wrefB;
        
                i = i+1;
        
                [ dRdx_patchA, dRdy_patchA, dRdz_patchA] = computeBasisDerivatives(PHUTelem,GIFTmesh,patchA,elemA(indexSeg),urefA,vrefA,wrefA,p,q,r );
                [ dRdx_patchB, dRdy_patchB, dRdz_patchB] = computeBasisDerivatives(PHUTelem,GIFTmesh,patchB,elemB(indexSeg),urefB,vrefB,wrefB,p,q,r );
    
                [a,b,c,d] = computeFunctionABC_GIFTmesh_vDirection(PHUTelem,GIFTmesh,patchA,elemA(indexSeg),patchB,elemB(indexSeg),refPoint);
                [m] = assignContinuityConstraints_v_method2(solIndex,basisIndex,m,i,a,b,c,d,dRdx_patchA,dRdy_patchA,dRdz_patchA,dRdx_patchB,dRdy_patchB,dRdz_patchB,p,q,r);
         
            elseif testU1 || testU2 || testU3

                wref = linspace(-1+fudge,1-fudge,numPtsV);
                vref = linspace(-1+fudge,1-fudge,numPtsU);
                uref = [];

                [refPoint] = assignRefPoint3D(iu,iv,uref,vref,wref,edgeA,edgeB);
                    
                urefA=refPoint.urefA;
                vrefA=refPoint.vrefA;
                wrefA=refPoint.wrefA;
                urefB=refPoint.urefB;
                vrefB=refPoint.vrefB;
                wrefB=refPoint.wrefB;
        
                i = i+1;
        
                [ dRdx_patchA, dRdy_patchA, dRdz_patchA] = computeBasisDerivatives(PHUTelem,GIFTmesh,patchA,elemA(indexSeg),urefA,vrefA,wrefA,p,q,r );
                [ dRdx_patchB, dRdy_patchB, dRdz_patchB] = computeBasisDerivatives(PHUTelem,GIFTmesh,patchB,elemB(indexSeg),urefB,vrefB,wrefB,p,q,r );
    
                [a,b,c,d] = computeFunctionABC_GIFTmesh_uDirection(PHUTelem,GIFTmesh,patchA,elemA(indexSeg),patchB,elemB(indexSeg),refPoint);
                [m] = assignContinuityConstraints_u_method2(solIndex,basisIndex,m,i,a,b,c,d,dRdx_patchA,dRdy_patchA,dRdz_patchA,dRdx_patchB,dRdy_patchB,dRdz_patchB,p,q,r);
    
                %need modification for continuity along w in numpoints section
    
            elseif testW1 || testW2 || testW3  % Handling W-direction continuity

                wref = [];
                vref = linspace(-1+fudge,1-fudge,numPtsV);
                uref = linspace(-1+fudge,1-fudge,numPtsU);

                [refPoint] = assignRefPoint3D(iu,iv,uref,vref,wref,edgeA,edgeB);
                    
                urefA=refPoint.urefA;
                vrefA=refPoint.vrefA;
                wrefA=refPoint.wrefA;
                urefB=refPoint.urefB;
                vrefB=refPoint.vrefB;
                wrefB=refPoint.wrefB;
        
                i = i+1;
        
                [ dRdx_patchA, dRdy_patchA, dRdz_patchA] = computeBasisDerivatives(PHUTelem,GIFTmesh,patchA,elemA(indexSeg),urefA,vrefA,wrefA,p,q,r );
                [ dRdx_patchB, dRdy_patchB, dRdz_patchB] = computeBasisDerivatives(PHUTelem,GIFTmesh,patchB,elemB(indexSeg),urefB,vrefB,wrefB,p,q,r );
                
                [a,b,c,d] = computeFunctionABC_GIFTmesh_wDirection(PHUTelem,GIFTmesh,patchA,elemA(indexSeg),patchB,elemB(indexSeg),refPoint);
                [m] = assignContinuityConstraints_w_method2(solIndex,basisIndex,m,i,a,b,c,d,dRdx_patchA,dRdy_patchA,dRdz_patchA,dRdx_patchB,dRdy_patchB,dRdz_patchB,p,q,r);
            
            else
                disp('error : undetermined case')
                pause
            end
            
        end
    end
    
end
end

