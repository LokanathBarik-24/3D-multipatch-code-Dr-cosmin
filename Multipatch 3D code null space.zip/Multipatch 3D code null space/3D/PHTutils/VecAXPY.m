function [y ] = VecAXPY( y,alpha,x )
%Computes y =  alpha x +y.
y=alpha*x+y;
end

