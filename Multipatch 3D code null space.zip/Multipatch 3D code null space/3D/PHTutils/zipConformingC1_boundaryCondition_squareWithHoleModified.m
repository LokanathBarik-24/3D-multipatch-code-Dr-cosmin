function [coefSol] = zipConformingC1_boundaryCondition_squareWithHoleModified( PHUTelem,m,p,q,r, test_sol,numElemV )

% Face encoding: 1 - front, 2 - right, 3 - back, 4 - left, 5 - down, 6 - up
right_nodes2 = (p+1)-1:(p+1):(p+1)*(q+1)*(r+1)-1;
right_nodes1 = (p+1):(p+1):(p+1)*(q+1)*(r+1);

left_nodes1 = 1:(p+1):(p+1)*(q+1)*(r+1);
left_nodes2 = 2:(p+1):(p+1)*(q+1)*(r+1);

front_nodes1=1:(p+1)*(q+1);
front_nodes2=front_nodes1+(p+1)*(q+1);

back_nodes1=(p+1)*(q+1)*(r)+1:(p+1)*(q+1)*(r+1);
back_nodes2=back_nodes1-(p+1)*(q+1);

down_nodes1=reshape([1:(p+1);(p+1)*(q+1)+1:(p+1)*(q+1)+(p+1);(p+1)*(q+1)*r+1:(p+1)*(q+1)*(r)+(p+1)],1,[]);
down_nodes2=down_nodes1+(p+1);

up_nodes1=reshape([(p+1)*(q+1)-p:(p+1)*(q+1);(p+1)*(q+p+1)+1:(p+1)*(q+p+1)+(p+1);(p+1)*(q+1)*(r+1)-p:(p+1)*(q+1)*(r+1)],1,[]);
up_nodes2=up_nodes1-(p+1);

leftNodes=[left_nodes1, left_nodes2];
rightNodes=[right_nodes1, right_nodes2];
upNodes=[up_nodes1, up_nodes2];
downNodes=[down_nodes1, down_nodes2];
frontNodes=[front_nodes1, front_nodes2];
backNodes=[back_nodes1, back_nodes2];

list=[];
for indexPatch=1
    for indexElem=1:length(PHUTelem{indexPatch})
        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_up)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(upNodes)];
        end
        
        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_down)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(downNodes)];
        end

        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_front)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(frontNodes)];
        end
        
        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_back)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(backNodes)];
        end
        
    end
end

indexPatch=2;
for indexElem=1:length(PHUTelem{indexPatch})
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_up)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(upNodes)];
    end
    
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_left)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(leftNodes)];
    end
        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_front)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(frontNodes)];
        end
        
        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_back)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(backNodes)];
        end
    
end

indexPatch=3;
for indexElem=1:length(PHUTelem{indexPatch})
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_right)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(rightNodes)];
    end
    
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_left)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(leftNodes)];
    end

        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_front)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(frontNodes)];
        end
        
        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_back)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(backNodes)];
        end
end


indexPatch=4;
for indexElem=1:length(PHUTelem{indexPatch})
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_down)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(downNodes)];
    end
    
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_left)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(leftNodes)];
    end

        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_front)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(frontNodes)];
        end
        
        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_back)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(backNodes)];
        end
end

indexPatch=5;
for indexElem=1:length(PHUTelem{indexPatch})
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_down)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(downNodes)];
    end
    
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_up)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(upNodes)];
    end

        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_front)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(frontNodes)];
        end
        
        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_back)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(backNodes)];
        end
end

indexPatch=6;
for indexElem=1:length(PHUTelem{indexPatch})
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_down)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(downNodes)];
    end
    
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_right)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(rightNodes)];
    end

        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_front)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(frontNodes)];
        end
        
        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_back)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(backNodes)];
        end
end


indexPatch=7;
for indexElem=1:length(PHUTelem{indexPatch})
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_left)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(leftNodes)];
    end
    
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_right)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(rightNodes)];
    end

        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_front)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(frontNodes)];
        end
        
        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_back)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(backNodes)];
        end
end

indexPatch=8;
for indexElem=1:length(PHUTelem{indexPatch})
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_up)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(upNodes)];
    end
    
    if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_right)
        list=[list,PHUTelem{indexPatch}(indexElem).solIndex(rightNodes)];
    end

        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_front)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(frontNodes)];
        end
        
        if  isempty(PHUTelem{indexPatch}(indexElem).neighbor_back)
            list=[list,PHUTelem{indexPatch}(indexElem).solIndex(backNodes)];
        end
end

list=nonzeros(list);
list=unique(list);

%loop to nullify the boundary solindex and remove in our analysis
for i=1:length(list)
    [a,b]=find(test_sol==list(i));
    test_sol(:,b)=[];
end


% test_sol(:,[1,end])=[];
temp=unique(test_sol', 'rows')';
temp=[temp,temp([3,2,1],:)];
% temp1(1,:)=temp(1,:);
% temp1(2,:)=temp(3,:);



% for i=1:length(temp1)
% [a,b]=find(test_sol==temp1(i));
% if a(1,1)==1
%     temp(2,i)=test_sol(3,b(1,1));
% elseif a(1,1)==2
%     temp(2,i)=test_sol(2,b(1,1));
% else
%     temp(2,i)=test_sol(1,b(1,1));
% end
% end

% determine the removed sequence for substitution 
rel=setdiff(1:size(m, 2), list);
m(:,list) = [];

% Initialize a zero matrix with the same number of rows and columns as the desired order
temp1 = zeros(size(temp, 1), length(rel));

% Find the column indices of the elements in desired order that exist in the matrix
[is_present, indices] = ismember(rel, temp(1, :));

% Populate the reordered matrix
temp1(:, is_present) = temp(:, indices(is_present));


% tempCoefSol = nullMDS_old(m);

tempCoefSol = nullMDS(m,temp1);

%add rows of zeros
coefSol=zeros(size(tempCoefSol,1)+length(list),size(tempCoefSol,2));
count=0;
for indexRow=1:size(coefSol,1)
    if  ~ismember(indexRow,list)
        count=count+1;
        coefSol(indexRow,:)=tempCoefSol(count,:);
    end
end

end

