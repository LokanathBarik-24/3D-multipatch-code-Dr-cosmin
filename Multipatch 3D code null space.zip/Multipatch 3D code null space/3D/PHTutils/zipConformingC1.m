function [PHUTelem,sizeBasis,numType2Basis,type2Basis] =zipConformingC1(PHUTelem,GIFTmesh,sizeBasis,patchBoundaries,solIndexCount,p,q)
%zipConforming without boundary condition

right_nodes2 = (p+1)-1:(p+1):(p+1)*(q+1)-1;
right_nodes1 = (p+1):(p+1):(p+1)*(q+1);

left_nodes1 = 1:(p+1):(1+(p+1)*q);
left_nodes2 = 2:(p+1):(1+(p+1)*q)+1;

down_nodes1=1:(p+1);
down_nodes2=down_nodes1+(p+1);

up_nodes1=(p+1)*(q+1)-p:(p+1)*(q+1);
up_nodes2=up_nodes1-(p+1);

[boundaryInfo,segInfo,subSegInfo,numSeg,patchNeighborInfo,patchEdgeInfo] = createBoundaryInfo3(PHUTelem, patchBoundaries );

numBoundaries = size(patchBoundaries,1);

numColumns=solIndexCount;
numPts=ceil(numColumns/numSeg);
if numPts<p+1
    numPts=p+1;
end

m=zeros(numPts*numSeg,numColumns);
i=0; vo=1;

for boundaryIndex = 1:numBoundaries
    patchAList = patchBoundaries(boundaryIndex,1);
    patchB = patchBoundaries(boundaryIndex,2);
    edgeAList = patchBoundaries(boundaryIndex,3);
    edgeBList = patchBoundaries(boundaryIndex,4);
    
    edgeAList=cell2mat(edgeAList);
    edgeBList=cell2mat(edgeBList);
    
    patchAList=cell2mat(patchAList);
    patchB=cell2mat(patchB);
    
    for indexPatch=1:length(patchAList)
        patchA = patchAList(indexPatch);
        edgeA = edgeAList(indexPatch);
        edgeB = edgeBList(indexPatch);
        
        [elemA] = sortEdgeElem( PHUTelem{patchA}, edgeA);
        [elemB] = sortEdgeElem( PHUTelem{patchB}, edgeB);
        
        elemA=elemA{1};
        elemB=elemB{1};
        
        patchInfo.patchA=patchA;
        patchInfo.patchB=patchB;
        patchInfo.edgeA=edgeA;
        patchInfo.edgeB=edgeB;
        patchInfo.elemA=elemA;
        patchInfo.elemB=elemB;
        
        % [m,i] = computeMatrixM(PHUTelem,GIFTmesh,patchInfo,m,i,p,q,numPts);
        [m,i,solIndex] = computeMatrixM_method2(PHUTelem,GIFTmesh,patchInfo,m,i,p,q,numPts);
        test_sol{1,vo}=solIndex;
        vo=vo+1;
    end
end

test_sol=cell2mat(test_sol);

%%%%%%%%% boundary condition for circle biharmonic
% list=[];
% for indexPatch=1:4
%     
%     elem = sortEdgeElem( PHUTelem{indexPatch}, 1);
%     elem=cell2mat(elem);
%     
%     for indexElem=elem
%         list=[list,PHUTelem{indexPatch}(indexElem).solIndex(down_nodes1),PHUTelem{indexPatch}(indexElem).solIndex(down_nodes2)];
%     end
%     
% end
% list=nonzeros(list);
% list=unique(list);
% 
% 
% m(:,list) = [];
% tempCoefSol = nullMDS(m);
% 
% %add rows of zeros
% coefSol=zeros(size(tempCoefSol,1)+length(list),size(tempCoefSol,2));
% count=0;
% for indexRow=1:size(coefSol,1)
%     if  ~ismember(indexRow,list)
%         count=count+1;
%         coefSol(indexRow,:)=tempCoefSol(count,:);
%     end
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% coefSol = nullMDS_old(m);

% %loop to nullify the boundary solindex and remove in our analysis
% for i=1:length(list)
%     [a,b]=find(test_sol==list(i));
%     test_sol(:,b)=[];
% end


% test_sol(:,[1,end])=[];
temp=unique(test_sol', 'rows')';
temp=[temp,temp([3,2,1],:)];
% temp1(1,:)=temp(1,:);
% temp1(2,:)=temp(3,:);



% for i=1:length(temp1)
% [a,b]=find(test_sol==temp1(i));
% if a(1,1)==1
%     temp(2,i)=test_sol(3,b(1,1));
% elseif a(1,1)==2
%     temp(2,i)=test_sol(2,b(1,1));
% else
%     temp(2,i)=test_sol(1,b(1,1));
% end
% end

% % determine the removed sequence for substitution 
% rel=setdiff(1:size(m, 2), list);
% m(:,list) = [];

% % Initialize a zero matrix with the same number of rows and columns as the desired order
% temp1 = zeros(size(temp, 1), length(rel));
% 
% % Find the column indices of the elements in desired order that exist in the matrix
% [is_present, indices] = ismember(rel, temp(1, :));
% 
% % Populate the reordered matrix
% temp1(:, is_present) = temp(:, indices(is_present));


% coefSol = nullMDS(m,temp);
coefSol = nullMDS_old(m);

numType2Basis=size(coefSol,2);

type2basisNodes=sizeBasis+1:sizeBasis+numType2Basis;
[PHUTelem ,type2Basis,sizeBasis] = assignNewNodesGlobal(PHUTelem,GIFTmesh,patchBoundaries,sizeBasis,type2basisNodes,p,q);
[PHUTelem] = modifyC(PHUTelem,coefSol,numType2Basis,patchEdgeInfo,boundaryInfo,type2Basis,p,q);

end