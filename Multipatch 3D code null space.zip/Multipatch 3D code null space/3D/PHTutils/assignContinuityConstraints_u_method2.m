function [ m ] = assignContinuityConstraints_u_method2(solIndex,basisIndex,m,i,a,b,c,d,dRdx_patch1,dRdy_patch1,dRdz_patch1,dRdx_patch2,dRdy_patch2,dRdz_patch2,p,q,r)
%Compute matrix m for v direction
%solSet=length(solIndex)/3;
%count=1;

solSet=size(solIndex,2);

for set=1:solSet
    
    index=solIndex(:,set);
    
    basisIndex1=basisIndex(1,set);
    basisIndex2=basisIndex(2,set);
    basisIndex3=basisIndex(3,set);
    basisIndex4=basisIndex(4,set);
    
    if index(1)~=0
        m(i,index(1))=a*dRdx_patch1(basisIndex1)+b*dRdy_patch1(basisIndex1)+c*dRdz_patch1(basisIndex1);
    end
    
    if index(2)~=0
        m(i,index(2))=a*dRdx_patch1(basisIndex2)+b*dRdy_patch1(basisIndex2)+c*dRdz_patch1(basisIndex2)+d*dRdx_patch2(basisIndex3);
    end
    
    if index(3)~=0
        m(i,index(3))=d*dRdx_patch2(basisIndex4);
    end
    
    
end


end

