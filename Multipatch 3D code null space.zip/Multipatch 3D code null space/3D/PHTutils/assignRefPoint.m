function [refPoint] = assignRefPoint( ic, uref,vref,wref,edgeA,edgeB )
%assign reference point based on face
% Face encoding: 1 - front, 2 - right, 3 - back, 4 - left, 5 - down, 6 - up

switch edgeA
    case 1
        vrefA=-1;
        urefA=uref(ic);
        wrefA=wref(ic);
    case 2
        vrefA=vref(ic);
        wrefA=wref(ic);
        urefA=1;
    case 3
        vrefA=1;
        urefA=uref(ic);
        wrefA=wref(ic);
    case 4
        vrefA=vref(ic);
        wrefA=wref(ic);
        urefA=-1;
    case 5
        urefA=uref(ic);
        vrefA=vref(ic);
        wrefA=-1;
    case 6
        urefA=uref(ic);
        vrefA=vref(ic);
        wrefA=1;
end

switch edgeB
    case 1
        vrefB=-1;
        urefB=uref(ic);
        wrefB=wref(ic);
    case 2
        vrefB=vref(ic);
        wrefB=wref(ic);
        urefB=1;
    case 3
        vrefB=1;
        urefB=uref(ic);
        wrefB=wref(ic);
    case 4
        vrefB=vref(ic);
        wrefB=wref(ic);
        urefB=-1;
    case 5
        urefB=uref(ic);
        vrefB=vref(ic);
        wrefB=-1;
    case 6
        urefB=uref(ic);
        vrefB=vref(ic);
        wrefB=1;
end

refPoint=struct;
refPoint.urefA=urefA;
refPoint.vrefA=vrefA;
refPoint.wrefA=wrefA;
refPoint.urefB=urefB;
refPoint.vrefB=vrefB;
refPoint.wrefB=wrefB;

end

