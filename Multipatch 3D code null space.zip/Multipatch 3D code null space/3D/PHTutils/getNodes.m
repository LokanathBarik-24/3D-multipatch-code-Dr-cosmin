function [nodes ] = getNodes(p,q,r)
nodes=struct;

% Face encoding: 1 - front, 2 - right, 3 - back, 4 - left, 5 - down, 6 - up

nodes.right_nodes1 = (p+1):(p+1):(p+1)*(q+1)*(r+1);
nodes.right_nodes2 = (p+1)-1:(p+1):(p+1)*(q+1)*(r+1)-1;
nodes.right_nodes3 = (p+1)-1:(p+1):(p+1)*(q+1)*(r+1)-2;

nodes.left_nodes1 = 1:(p+1):(p+1)*(q+1)*(r+1);
nodes.left_nodes2 = 2:(p+1):(p+1)*(q+1)*(r+1);
nodes.left_nodes3 = 3:(p+1):(p+1)*(q+1)*(r+1);

nodes.down_nodes1=1:(p+1)*(q+1);
nodes.down_nodes2=nodes.down_nodes1+(p+1)*(q+1);
nodes.down_nodes3=nodes.down_nodes2+(p+1)*(q+1);

nodes.up_nodes1=(p+1)*(q+1)*(r)+1:(p+1)*(q+1)*(r+1);
nodes.up_nodes2=nodes.up_nodes1-(p+1)*(q+1);
nodes.up_nodes3=nodes.up_nodes2-(p+1)*(q+1);

nodes.front_nodes1=reshape((1:p+1)' + (0:r)*(p+1)*(q+1), 1, []);
nodes.front_nodes2=nodes.front_nodes1+(p+1);
nodes.front_nodes3=nodes.front_nodes2+(p+1);

nodes.back_nodes1=reshape((p*(q+1)+1:(p+1)*(q+1))' + (0:r)*(p+1)*(q+1), 1, []);
nodes.back_nodes2=nodes.back_nodes1-(p+1);
nodes.back_nodes3=nodes.back_nodes2-(p+1);
end


