function PlotDispPlate_c1( PHTelem, GIFTmesh,  p, q, r, sol)
%plots the Z displacement for the plate problem and calculates the minimum
%displacement from the plotting data
%uses GIFT mapping
%supports multipatches
%use modified C

figure
numPts = 21; %number of plot points to use on each edge
fudge = 0;
uref = linspace(-1+fudge,1-fudge,numPts);
vref = linspace(-1+fudge,1-fudge,numPts);
wref = linspace(-1+fudge,1-fudge,numPts);
maxZ = -Inf;

%1D bernstein polynomials evaluated at the Gauss points on the master element
[B_u,~] = bernstein_basis(uref,p);
[B_v,~] = bernstein_basis(vref,q);
[B_w,~] = bernstein_basis(wref,r);

Buvw = zeros(numPts, numPts, numPts , (p+1)*(q+1)*(r+1));

%the derivatives of the 2D Bernstein polynomials at Gauss points on the
%master element
basisCounter = 0;
for k=1:r+1
    for j=1:q+1
        for i=1:p+1
            basisCounter = basisCounter + 1;
            for kk=1:numPts
                for jj=1:numPts
                    for ii=1:numPts
                        Buvw(ii,jj,kk,basisCounter) = B_u(ii,i)*B_v(jj,j)*B_w(kk,k);
                    end
                end
            end
        end
    end
end

for patchIndex = 1:length(PHTelem)
    for i=1:length(PHTelem{patchIndex})
        if isempty(PHTelem{patchIndex}(i).children)
            xmin = PHTelem{patchIndex}(i).vertex(1);
            xmax = PHTelem{patchIndex}(i).vertex(4);
            ymin = PHTelem{patchIndex}(i).vertex(2);
            ymax = PHTelem{patchIndex}(i).vertex(5);
            zmin = PHTelem{patchIndex}(i).vertex(3);
            zmax = PHTelem{patchIndex}(i).vertex(6);
            
            globalNodes=PHTelem{patchIndex}(i).nodesGlobal;
            tempDisp=sol(globalNodes);
            coords=zeros(numPts,numPts,numPts,3);
            disp=zeros(numPts,numPts,numPts);
            %loop over the ngauss_x x ngauss_y gauss points on each element
            
            for kk=1:numPts
                for jj=1:numPts
                    for ii=1:numPts
                        %evaluate the derivatives of the mapping from parameter
                        %space to physical space
                        
                        [coord, dxdxi] = paramMap3D( GIFTmesh{patchIndex}, uref(ii), vref(jj), wref(kk), xmin, ymin, zmin, xmax, ymax, zmax);

                        coords(ii,jj,kk,:)=[coord(1),coord(2),coord(3)];
                        R = (PHTelem{patchIndex}(i).modifiedC)*squeeze(Buvw(ii,jj,kk,:));
                        disp(ii,jj,kk)=R'*tempDisp;
                        
                    end
                end
            end

            x=coords(:,:,:,1); y=coords(:,:,:,2); z=coords(:,:,:,3);
         %   maxZ = max([maxZ; disp(:)]);
             scatter3(x(:), y(:), z(:), 36, disp(:), 'filled') % 36 is marker size
            % surf(coords(:,:,1), coords(:,:,2),disp,'EdgeColor', 'none')
            hold on
            
        end
    end
end
