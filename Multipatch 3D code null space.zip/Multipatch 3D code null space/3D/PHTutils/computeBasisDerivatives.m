function [c_dRdu,c_dRdv,c_dRdw] = computeBasisDerivatives(PHUTelem,GIFTmesh,indexPatch,indexElem,uref,vref,wref,p,q,r )
%disp('in compute Basis derivatives')

[B_u,dB_u] = bernstein_basis(uref,p);
[B_v,dB_v] = bernstein_basis(vref,q);
[B_w,dB_w] = bernstein_basis(wref,r);

R = zeros(1,1, (p+1)*(q+1)*(r+1));
dRdu = zeros(1,1, (p+1)*(q+1)*(r+1));
dRdv = zeros(1,1, (p+1)*(q+1)*(r+1));
dRdw = zeros(1,1, (p+1)*(q+1)*(r+1));

basisCounter = 0;
for k = 1:r+1   % W-direction
    for j = 1:q+1   % V-direction
        for i = 1:p+1   % U-direction
            basisCounter = basisCounter + 1;
            R(:,:,basisCounter) = B_u(:,i) * B_v(:,j)' * B_w(:,k);
            dRdu(:,:,basisCounter) = dB_u(:,i) * B_v(:,j)' * B_w(:,k);
            dRdv(:,:,basisCounter) = B_u(:,i) * dB_v(:,j)' * B_w(:,k);
            dRdw(:,:,basisCounter) = B_u(:,i) * B_v(:,j)' * dB_w(:,k);
        end
    end
end

numBasis = length(PHUTelem{indexPatch}(indexElem).nodesGlobal);

c_dRdu = zeros(1, numBasis);
c_dRdv = zeros(1, numBasis);
c_dRdw = zeros(1, numBasis); % Add derivative in W-direction

for index = 1:numBasis
    c_dRdu(index) = PHUTelem{indexPatch}(indexElem).C(index,:) * dRdu(:);
    c_dRdv(index) = PHUTelem{indexPatch}(indexElem).C(index,:) * dRdv(:);
    c_dRdw(index) = PHUTelem{indexPatch}(indexElem).C(index,:) * dRdw(:);
end
end
