function [ PHTelem, dimBasis,lenVec] = initPHTmesh_quadratic( p,q,r,numElemU,numElemV, numElemW)


knotU = [zeros(1,p+1), (1:numElemU)/numElemU, ones(1,p)];
knotV = [zeros(1,q+1), (1:numElemV)/numElemV, ones(1,q)];
knotW = [zeros(1,q+1), (1:numElemW)/numElemW, ones(1,r)];


[C_u, ~] = bezierExtraction(knotU,p);
[C_v, ~] = bezierExtraction(knotV,q);
[C_w, ~] = bezierExtraction(knotW,r);

lenU = length(knotU)-p-1;
lenV = length(knotV)-q-1;
lenW = length(knotW)-r-1;

lenVec=[lenU,lenV,lenW];


dimBasis = lenU*lenV*lenW;
numElements = numElemU*numElemV*numElemW;

PHTelem = struct;
%initialize the neighbor connectivity lists
PHTelem.neighbor_left = [];
PHTelem.neighbor_right = [];
PHTelem.neighbor_down = [];
PHTelem.neighbor_up = [];
PHTelem.neighbor_front = [];
PHTelem.neighbor_back = [];

%loop through each element and compute the element-node connectivities
nument = (p+1)*(q+1)*(r+1);
elementCounter = 0;

for k = 1:length(knotW)-1
    for j=1:length(knotV)-1
        for i=1:length(knotU)-1
            if (knotU(i+1)>knotU(i)) && (knotV(j+1) >knotV(j)) && (knotW(k+1) > knotW(k)) %the knotspan has non-zero area
                elementCounter = elementCounter + 1;
                PHTelem(elementCounter).parent = [];
                PHTelem(elementCounter).children = [];
                PHTelem(elementCounter).vertex = [knotU(i), knotV(j), knotW(k), knotU(i+1), knotV(j+1), knotW(k+1)];
                
                tcount = 0;
                currow = zeros(1, nument);
                %now we add the nodes from i-p...i in the u
                %direction, j-q...j in the v direction
                %direction, k-r...k in the w direction
                
                for t3 = k-r:k
                    for t2 = j-q:j
                        for t1 = i-p:i
                            tcount = tcount + 1;
                            currow(tcount) = t1 + (t2-1) * lenU + (t3-1) * lenU * lenV;
                        end
                    end
                end
                
                PHTelem(elementCounter).nodes=currow;
                PHTelem(elementCounter).level = 0;
                
            end
        end
    end
end


%loop through each element and compute the neighbor lists and Bezier
%extraction operators
indexMatrix = permute(reshape(1:numElements, numElemU, numElemV, numElemW),[2,1,3]);

for k = 1:numElemW
    for j=1:numElemV
        for i=1:numElemU
            elementIndex = indexMatrix(j,i,k);
            PHTelem(elementIndex).C = kron(kron(C_w(:, :, k), C_v(:, :, j)), C_u(:, :, i));
            
            if i>1
                PHTelem(elementIndex).neighbor_left = indexMatrix(j,(i-1),k);
            end
            if i<numElemU
                PHTelem(elementIndex).neighbor_right = indexMatrix(j,(i+1),k);
            end
            
            if j>1
                PHTelem(elementIndex).neighbor_front = indexMatrix((j-1),i,k);
            end
            if j<numElemV
                PHTelem(elementIndex).neighbor_back = indexMatrix((j+1),i,k);
            end

            if k>1
                PHTelem(elementIndex).neighbor_down = indexMatrix(j,i,k-1);
            end
            if k<numElemW
                PHTelem(elementIndex).neighbor_up = indexMatrix(j,i,k+1);
            end
        end
    end
end

end

